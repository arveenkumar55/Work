//
//  File.swift
//  Frieght Frenzy App
//
//  Created by Mac on 2021-11-03.
//  Copyright © 2021 Mac. All rights reserved.
//

import Foundation

import CoreData

class CoreDataManager {
    
    let persistentContainer : NSPersistentContainer
    
    init() {
        persistentContainer = NSPersistentContainer(name : "TeamDataModel")
        persistentContainer.loadPersistentStores { (description, error) in
            if let error = error {
                fatalError("Data store failed \(error.localizedDescription)")
            }
        }
    }
    
    func getTeamsData() -> [FFTeam] {
        
        let fetchRequest : NSFetchRequest<FFTeam> = FFTeam.fetchRequest()
        do {
            return try persistentContainer.viewContext.fetch(fetchRequest)
        }
        catch {
            return []
        }
    }
    
    func deleteAllTeamData() {
        print("in delete request")
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName : "FFTeam")
        fetchRequest.returnsObjectsAsFaults = false
        do {
            let results = try persistentContainer.viewContext.fetch(fetchRequest)
            for object in results {
                print("deleting")
                print(object)
                guard let objectData = object as? NSManagedObject else {continue}
                persistentContainer.viewContext.delete(objectData)
            }
        }
        catch let error {
            print("Error occured while deleting \(error.localizedDescription)")
        }
    }

    func storeTeamData(id: String, name: String, location: String, image: String, created: String) {
        let team = FFTeam(context: persistentContainer.viewContext)
        team.id = id
        team.name = name
        team.location = location
        team.image = image
        team.created = created
        
        do {
            try persistentContainer.viewContext.save()
        }
        catch {
            print("Failed to save team data \(error)")
        }
    }
    
    func isExist(id : String, name : String) -> Bool {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "FFTeam")
        fetchRequest.predicate = NSPredicate(format: "id == %@ AND name == %@", argumentArray : [id, name])
        
        let res = try! persistentContainer.viewContext.fetch(fetchRequest)
        return res.count > 0 ? true : false
    }
}
