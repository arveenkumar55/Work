//
//  LoginViewController.swift
//  Frieght Frenzy App
//
//  Created by Mac on 2021-11-02.
//  Copyright © 2021 Mac. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var teamId: UITextField!
    @IBOutlet weak var teamName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func login(_ sender: Any) {
        
        if teamId.text?.isEmpty == true {
            createErrorAlert(errorMessage: "Enter the team id to login")
        }
        else if teamName.text?.isEmpty == true {
            createErrorAlert(errorMessage: "Enter the team name to login")
        }
        else {
            
            let coreDM : CoreDataManager = CoreDataManager()
            
            if(coreDM.isExist(id: teamId.text!, name: teamName.text!)) {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyboard.instantiateViewController(identifier: "HomePage")
                vc.modalPresentationStyle = .overFullScreen
                present(vc, animated: true)
            }
            else {
                createRegisterAlert()
            }
        }
    }
    
    func createErrorAlert(errorMessage : String) {
        let alertController = UIAlertController(title: "Data incorrect", message: errorMessage, preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Close", style: .cancel, handler: nil))
        
        self.present(alertController, animated: true)
    }
    
    func createRegisterAlert() {
        let alertController = UIAlertController(title: "Team not registered", message: "Entered data is not registered with us. Kindly register your team or enter with correct data", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Close", style: .cancel, handler: nil))
        
        self.present(alertController, animated: true)
    }
    
}
