//
//  ViewController.swift
//  Frieght Frenzy App
//
//  Created by Mac on 2021-10-30.
//  Copyright © 2021 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        print("fetching")
        
    }
}

