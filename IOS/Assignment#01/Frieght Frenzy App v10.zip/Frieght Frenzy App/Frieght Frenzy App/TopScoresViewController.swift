//
//  TopScoresViewController.swift
//  Frieght Frenzy App
//
//  Created by Mac on 2021-11-02.
//  Copyright © 2021 Mac. All rights reserved.
//

import UIKit

class TopScoresViewController: UIViewController {
    
    private var teams : [FFTeam] = [FFTeam]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let coreDM : CoreDataManager = CoreDataManager()
        self.teams = coreDM.getTeamsData()
        
        let t : [FFTeam] = coreDM.getTeamsData()
        
        print(t.count)
                
        //for ff in t {
            //print(String(ff.name ?? ""))
        //}

        // Do any additional setup after loading the view.
    }
    
    @IBAction func home(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "HomePage")
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    
}
