//
//  MainViewController.swift
//  Frieght Frenzy App
//
//  Created by Mac on 2021-11-02.
//  Copyright © 2021 Mac. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var registerButton: UIButton!
        
    var teamsList : [TeamDetails] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        print("here in main controller")
        let url = "https://partiklezoo.com/freightfrenzy/?action=teams"
        getData(from: url)

        // Do any additional setup after loading the view.
    }
    
    private func getData(from url : String) {
        let task = URLSession.shared.dataTask(with: URL(string: url)!, completionHandler: {data, response, error in
            
            guard let data = data, error == nil else {
                print("Error occured in fetching data")
                return
            }
            
            var response : [TeamDetails]?
            do {
                let decoder = JSONDecoder()
                response = try decoder.decode([TeamDetails].self, from: data)
            }
            catch {
                print("Failed to convert received data")
                print(String (describing: error))
            }
            
            guard let json = response else {
                return
            }
            
            let coreDM : CoreDataManager = CoreDataManager()
            
            for jsonData in json {
                if(!coreDM.isExist(id: jsonData.id, name: jsonData.name)) {
                    coreDM.storeTeamData(id: jsonData.id, name: jsonData.name, location: jsonData.location, image: jsonData.image, created: jsonData.created)
                }
                self.teamsList.append(jsonData)
            }
        })
        
        task.resume()
    }
    

    @IBAction func login(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "LoginPage")
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    
    @IBAction func register(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "RegistrationPage")
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
}


struct TeamsData : Codable {
    let teams : [TeamDetails]
}

struct TeamDetails : Codable {
    let id : String
    let name : String
    let location : String
    let image : String
    let created : String
}
