//
//  RegistrationViewController.swift
//  Frieght Frenzy App
//
//  Created by Mac on 2021-11-02.
//  Copyright © 2021 Mac. All rights reserved.
//

import UIKit

class RegistrationViewController: UIViewController {

    @IBOutlet weak var privacy: UISwitch!
    @IBOutlet weak var teamId: UITextField!
    @IBOutlet weak var teamName: UITextField!
    @IBOutlet weak var region: UITextField!
    @IBOutlet weak var robotName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func register(_ sender: Any) {
        
        if teamId.text?.isEmpty == true {
            createErrorAlert(errorMessage: "Enter the team id to login")
        }
        else if teamName.text?.isEmpty == true {
            createErrorAlert(errorMessage: "Enter the team name to login")
        }
        
        else {
            let coreDM : CoreDataManager = CoreDataManager()
            
            if(!coreDM.isExist(id: teamId.text!, name: teamName.text!)) {
                
                registerTeamWithData()
                
                goToHomepage()
                //createErrorAlert(errorMessage: "Error occured while registering team")
                                
            }
            else {
                createLoginAlert()
            }
        }
    }
    
    func registerTeamWithData() {
        
        let url = URL(string : "https://partiklezoo.com/freightfrenzy/?action=addteam&id=\(teamId.text!)&name=\(teamName.text!)&location=\(region.text!)")
        let task = URLSession.shared.dataTask(with: url!, completionHandler: {data, response, error in
            
            guard let data = data, error == nil else {
                print("Error occured in registering team")
                return
            }
            
            var response : RegisterResponse?
            do {
                let decoder = JSONDecoder()
                response = try decoder.decode(RegisterResponse.self, from: data)
            }
            catch {
                print("Failed to convert received data")
                print(String (describing: error))
            }
            
            guard let json = response else {
                return
            }
                        
            print(json.result)
            
        })
        
        task.resume()
                
    }
    
    func goToHomepage() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "HomePage")
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    
    func createErrorAlert(errorMessage : String) {
        let alertController = UIAlertController(title: "Data incorrect", message: errorMessage, preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Close", style: .cancel, handler: nil))
        
        self.present(alertController, animated: true)
    }
    
    func createLoginAlert() {
        let alertController = UIAlertController(title: "Team already registered", message: "Team with given details is already present. Kindly login your team or enter with different data", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Close", style: .cancel, handler: nil))
        
        self.present(alertController, animated: true)
    }

}

struct RegisterResponse : Codable {
    let result : String
    let message : String?
    let action : String?
}
