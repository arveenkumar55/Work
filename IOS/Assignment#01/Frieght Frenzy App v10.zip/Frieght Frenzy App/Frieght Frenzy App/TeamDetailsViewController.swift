//
//  TeamDetailsViewController.swift
//  Frieght Frenzy App
//
//  Created by Mac on 2021-11-02.
//  Copyright © 2021 Mac. All rights reserved.
//

import UIKit

class TeamDetailsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func home(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(identifier: "MainPage")
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    
}
