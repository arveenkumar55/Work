//
//  ContentView.swift
//  HPConverter
//
//  Created by Rakesh on 12/09/21.
//  Copyright © 2021 Assignment. All rights reserved.
//

import SwiftUI
import Combine

struct ContentView: View {
    var body: some View {
        Home().preferredColorScheme(.dark)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home : View {
    
    @State var index = 0
    
    var body : some View {
        GeometryReader{ _ in
            VStack {
                
                ZStack {
                    MainFeature(index : self.$index).zIndex(Double(self.index))
                    
                    BonusFeature(index : self.$index)
                }
            }
        }
        .background(Color("Color").edgesIgnoringSafeArea(.all))
    }
}

struct CShape : Shape {
    func path(in rect : CGRect) -> Path {
        return Path{path in
            path.move(to: CGPoint(x: rect.width, y: 100))
            path.addLine(to: CGPoint(x:rect.width, y:rect.height))
            path.addLine(to: CGPoint(x: 0, y:rect.height))
            path.addLine(to: CGPoint(x:0, y:0))
        }
    }
}

struct MainFeature : View {
    
    @State var hpm = ""
    @State var hpe = ""
    @State var hpi = ""
    @State var outputKW1 = ""
    @State var outputKW2 = ""
    @State var outputKW3 = ""
    @Binding var index : Int

    var body : some View {
        VStack {
            VStack {
                HStack {
                    VStack(spacing : 10) {
                        Text("Main").foregroundColor(self.index == 0 ? .white : .gray)
                            .font(.title)
                            .fontWeight(.bold)
                            .onTapGesture {
                                self.index = 0
                            }
                        Capsule()
                            .fill(self.index == 0 ? Color.blue : Color.clear)
                            .frame(width : 100, height : 5)
                    }
                    Spacer(minLength : 0)
                }
                .padding(.top, 30)
                
                VStack {
                    HStack(spacing : 15) {
                        Text("HP : ")
                        
                        TextField("metric", text: self.$hpm)
                            .keyboardType(.decimalPad)
                                .onReceive(Just(self.hpm)) { newValue in
                                    let cleanValue = newValue.filter { "0123456789.".contains($0) }
                                    if cleanValue != newValue {
                                        self.hpm = cleanValue
                                    }
                            }
                        
                    }
                    
                    HStack {
                        Text("kW = ")
                        
                        Spacer()
                        
                        Text("\(self.outputKW1)")
                    }
                    
                    Divider().background(Color.white.opacity(0.5))
                }
                .padding(.horizontal)
                .padding(.top,40)
                
                VStack {
                    HStack(spacing : 15) {
                        Text("HP : ")
                        
                        TextField("electrical", text: self.$hpe)
                        .keyboardType(.decimalPad)
                            .onReceive(Just(self.hpe)) { newValue in
                                let cleanValue = newValue.filter { "0123456789.".contains($0) }
                                if cleanValue != newValue {
                                    self.hpe = cleanValue
                                }
                        }
                    }
                    
                    HStack {
                        Text("kW = ")
                        
                        Spacer()
                        
                        Text("\(self.outputKW2)")
                    }
                    
                    Divider().background(Color.white.opacity(0.5))
                }
                .padding(.horizontal)
                .padding(.top,20)
                
                VStack {
                    HStack(spacing : 15) {
                        Text("HP : ")
                        
                        TextField("mechanical", text: self.$hpi)
                        .keyboardType(.decimalPad)
                            .onReceive(Just(self.hpi)) { newValue in
                                let cleanValue = newValue.filter { "0123456789.".contains($0) }
                                if cleanValue != newValue {
                                    self.hpi = cleanValue
                                }
                        }
                    }
                    
                    HStack {
                        Text("kW = ")
                        
                        Spacer()
                        
                        Text("\(self.outputKW3)")
                    }
                    Divider().background(Color.white.opacity(0.5))
                }
                .padding(.horizontal)
                .padding(.top,20)
                
            }
            .padding()
            .padding(.bottom,50)
            .background(Color("Color2"))
            .clipShape(CShape())
            .contentShape(CShape())
            .cornerRadius(35)
            .padding(.horizontal,10)
            .shadow(color: Color.black.opacity(0.3), radius : 5, x:0, y:-5)
            
            HStack {
                Button(action: {
                    //call convert function
                    self.convert()
                }) {
                    Text("CONVERT")
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .padding(.vertical)
                        .padding(.horizontal, 50)
                        .background(Color("Color1"))
                        .clipShape(Capsule())
                        .shadow(color : Color.white.opacity(0.1), radius: 5, x:0, y:5)
                }
                //.offset(y:25)
                
                Spacer()
                
                Button(action: {
                    //call convert function
                    self.clearInput()
                }) {
                    Text("CLEAR")
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .padding(.vertical)
                        .padding(.horizontal, 50)
                        .background(Color("Color3"))
                        .clipShape(Capsule())
                        .shadow(color : Color.white.opacity(0.1), radius: 5, x:0, y:5)
                }
                
            }
            .opacity(self.index == 0 ? 1 : 0)
        }
        
    }
    
    func convert() {
        if self.hpm != "" {
            
            //let expression = NSExpression(format: self.hpm)
            //let result = expression.expressionValue(with: nil, context: nil) as! Double
            
            if let num = Double(self.hpm) {
                let output = num * 0.73549875
                self.outputKW1 = String(output)
            }
        }
        
        if self.hpe != "" {
            if let num = Double(self.hpe) {
                let output = num * 0.746
                self.outputKW1 = String(output)
            }
        }
        
        if self.hpi != "" {
            if let num = Double(self.hpi) {
                let output = num * 0.745699872
                self.outputKW1 = String(output)
            }
        }
    }
    
    func clearInput() {
        self.hpm = ""
        self.hpe = ""
        self.hpi = ""
    }
}

struct BonusCShape : Shape {
    func path(in rect : CGRect) -> Path {
        return Path{path in
            path.move(to: CGPoint(x: 0, y: 100))
            path.addLine(to: CGPoint(x: 0, y:rect.height))
            path.addLine(to: CGPoint(x: rect.width, y:rect.height))
            path.addLine(to: CGPoint(x: rect.width, y:0))
        }
    }
}
struct BonusFeature : View {
    
    @State var kw1 = ""
    @State var kw2 = ""
    @State var kw3 = ""
    @State var outputHPM = ""
    @State var outputHPE = ""
    @State var outputHPI = ""
    @Binding var index : Int

    var body : some View {
        VStack {
            VStack {
                HStack {
                    
                    Spacer(minLength : 0)
                    
                    VStack(spacing : 10) {
                        Text("Bonus").foregroundColor(self.index == 1 ? .white : .gray)
                            .font(.title)
                            .fontWeight(.bold)
                            .onTapGesture {
                                self.index = 1
                            }
                        Capsule()
                            .fill(self.index == 1 ? Color.blue : Color.clear)
                            .frame(width : 100, height: 5)
                    }
                    
                }
                .padding(.top, 30)
                
                VStack {
                    HStack(spacing : 15) {
                        Text("kW :")
                        
                        TextField("kW to HP(M)", text: self.$kw1)
                        .keyboardType(.decimalPad)
                            .onReceive(Just(self.kw1)) { newValue in
                                let cleanValue = newValue.filter { "0123456789.".contains($0) }
                                if cleanValue != newValue {
                                    self.kw1 = cleanValue
                                }
                        }
                    
                    }
                    
                    HStack {
                        Text("HP = ")
                        
                        Spacer()
                        
                        Text("\(self.outputHPM)")
                    }
                    Divider().background(Color.white.opacity(0.5))
                }
                .padding(.horizontal)
                .padding(.top,40)
                
                VStack {
                    HStack(spacing : 15) {
                        Text("kW :")
                        
                        TextField("kW to HP(E)", text: self.$kw2)
                        .keyboardType(.decimalPad)
                            .onReceive(Just(self.kw2)) { newValue in
                                let cleanValue = newValue.filter { "0123456789.".contains($0) }
                                if cleanValue != newValue {
                                    self.kw2 = cleanValue
                                }
                        }
                    }
                    
                    HStack {
                        Text("HP = ")
                        
                        Spacer()
                        
                        Text("\(self.outputHPE)")
                    }
                    Divider().background(Color.white.opacity(0.5))
                }
                .padding(.horizontal)
                .padding(.top,20)
                
                VStack {
                    HStack(spacing : 15) {
                        Text("kW :")
                        
                        TextField("kW to HP(I)", text: self.$kw3)
                        .keyboardType(.decimalPad)
                            .onReceive(Just(self.kw3)) { newValue in
                                let cleanValue = newValue.filter { "0123456789.".contains($0) }
                                if cleanValue != newValue {
                                    self.kw3 = cleanValue
                                }
                        }
                        
                    }
                    
                    HStack {
                        Text("HP = ")
                        
                        Spacer()
                        
                        Text("\(self.outputHPI)")
                    }
                    Divider().background(Color.white.opacity(0.5))
                }
                .padding(.horizontal)
                .padding(.top,20)
                
            }
            .padding()
            .padding(.bottom,50)
            .background(Color("Color2"))
            .clipShape(BonusCShape())
            .contentShape(BonusCShape())
            .cornerRadius(35)
            .padding(.horizontal,10)
            .shadow(color: Color.black.opacity(0.3), radius : 5, x:0, y:-5)
            
            
            HStack {
                Button(action: {
                    //call convert 1 function
                    self.convert1()
                }) {
                    Text("CONVERT")
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .padding(.vertical)
                        .padding(.horizontal, 50)
                        .background(Color("Color1"))
                        .clipShape(Capsule())
                        .shadow(color : Color.white.opacity(0.1), radius: 5, x:0, y:5)
                }
                //.offset(y:25)
                
                Spacer()
                
                Button(action: {
                    //call convert function
                    self.clearInput()
                }) {
                    Text("CLEAR")
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .padding(.vertical)
                        .padding(.horizontal, 50)
                        .background(Color("Color3"))
                        .clipShape(Capsule())
                        .shadow(color : Color.white.opacity(0.1), radius: 5, x:0, y:5)
                }
            }
            .opacity(self.index == 1 ? 1 : 0)
        }
        
    }
    
    func convert1() {
        if self.kw1 != "" {
            if let num = Double(self.kw1) {
                let output = num / 0.73549875
                self.outputHPM = String(output)
            }
        }
        if self.kw2 != "" {
            if let num = Double(self.kw2) {
                let output = num / 0.746
                self.outputHPE = String(output)
            }
        }
        if self.kw3 != "" {
            if let num = Double(self.kw3) {
                let output = num / 0.745699872
                self.outputHPI = String(output)
            }
        }
    }
    
    func clearInput() {
        self.kw1 = ""
        self.kw2 = ""
        self.kw3 = ""
    }
}
