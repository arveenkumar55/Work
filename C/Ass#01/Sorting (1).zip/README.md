## CSC 374: Computer Systems II: 2022 Winter Assignment #1

### Last Modified 2022 January 11

#### Purpose:

To go over:

- Compiler optimizations
- Program profiling (timing)
- Header files
- Linking and object file layout

#### Computing

Please [ssh](http://www.putty.org/) into one of the following:

- 140.192.36.184
- 140.192.36.185
- 140.192.36.186
- 140.192.36.187

or use your own Linux machine.

Please submit a .zip file (*not* .7z or any other non-standard compression!) file of your header file, the C files, *
and* a .txt/.pdf/.doc/.odt file containing your answer to the questions.

1.  #### Please copy-and-paste the following files (0 Points):

##### insertionSort.c

```c
/*--------------------------------------------------------------------------*
 *----									----*
 *----		insertionSort.c						----*
 *----									----*
 *----	    This file defines a function that implements insertion	----*
 *----	sort on a linked-list of integers.				----*
 *----									----*
 *----	----	----	----	----	----	----	----	----	----*
 *----									----*
 *----	Version 1a					Joseph Phillips	----*
 *----									----*
 *--------------------------------------------------------------------------*/

#include    "headers.h"


//  PURPOSE:  To sort the linked-list of nodes pointed to by 'nodePtr' using
//	the insertion sort algorithm.  Returns the first node of the sorted
//	list.
struct Node *insertionSort(struct Node *nodePtr) {
    struct Node *startPtr = NULL;
    struct Node *endPtr = NULL;
    struct Node *lowestPtr;
    struct Node *lowestPrevPtr;

    while (nodePtr != NULL) {
        struct Node *prevPtr;
        struct Node *run;

        lowestPrevPtr = NULL;
        lowestPtr = nodePtr;

        for (prevPtr = nodePtr, run = nodePtr->nextPtr_;
             run != NULL;
             prevPtr = run, run = run->nextPtr_
                ) {
            if (lowestPtr->value_ > run->value_) {
                lowestPtr = run;
                lowestPrevPtr = prevPtr;
            }
        }

        if (lowestPrevPtr == NULL) {
            if (startPtr == NULL) {
                startPtr = endPtr = lowestPtr;
            } else {
                endPtr->nextPtr_ = lowestPtr;
                endPtr = endPtr->nextPtr_;
            }

            nodePtr = nodePtr->nextPtr_;
            endPtr->nextPtr_ = NULL;
        } else {
            if (startPtr == NULL) {
                startPtr = endPtr = lowestPtr;
            } else {
                endPtr->nextPtr_ = lowestPtr;
                endPtr = endPtr->nextPtr_;
            }

            lowestPrevPtr->nextPtr_ = lowestPtr->nextPtr_;
            endPtr->nextPtr_ = NULL;
        }
    }

    print(startPtr);
    return (startPtr);
}
```

##### mergeSort.c

```c
/*--------------------------------------------------------------------------*
 *----									----*
 *----		mergeSort.c						----*
 *----									----*
 *----	    This file defines a function that implements merge-sort on	----*
 *----	a linked-list of integers.		       			----*
 *----									----*
 *----	----	----	----	----	----	----	----	----	----*
 *----									----*
 *----	Version 1a					Joseph Phillips	----*
 *----									----*
 *--------------------------------------------------------------------------*/

#include    "headers.h"


//  PURPOSE:  To sort the linked-list of nodes pointed to by 'nodePtr' using
//	the merge sort algorithm.  Returns the first node of the sorted	list.
struct Node *mergeSort(struct Node *nodePtr) {
    if ((nodePtr == NULL) || (nodePtr->nextPtr_ == NULL)) {
        return (nodePtr);
    }

    struct Node *run;
    struct Node *run2;
    struct Node *lastPtr = NULL;

    for (run = run2 = nodePtr;
         (run2 != NULL) && (run2->nextPtr_ != NULL);
         lastPtr = run, run = run->nextPtr_, run2 = run2->nextPtr_->nextPtr_
            );

    lastPtr->nextPtr_ = NULL;
    run2 = mergeSort(run);
    run = mergeSort(nodePtr);

    nodePtr = NULL;
    lastPtr = NULL;

    while ((run != NULL) && (run2 != NULL)) {
        if (run->value_ < run2->value_) {
            if (nodePtr == NULL) {
                nodePtr = lastPtr = run;
            } else {
                lastPtr = lastPtr->nextPtr_ = run;
            }

            run = run->nextPtr_;
        } else {
            if (nodePtr == NULL) {
                nodePtr = lastPtr = run2;
            } else {
                lastPtr = lastPtr->nextPtr_ = run2;
            }

            run2 = run2->nextPtr_;
        }
    }

    if (run == NULL) {
        if (lastPtr == NULL) {
            nodePtr = run2;
        } else {
            lastPtr->nextPtr_ = run2;
        }
    } else {
        if (lastPtr == NULL) {
            nodePtr = run;
        } else {
            lastPtr->nextPtr_ = run;
        }
    }

    return (nodePtr);
}

struct Node *mergeSortWrapper(struct Node *nodePtr) {
    nodePtr = mergeSort(nodePtr);

    print(nodePtr);
    return (nodePtr);
}
```

2.  #### C programming (20 Points):

    These two files need a `main()` to run their functions
    `insertionSort()` and `mergeSortWrapper()`. Then all three C files need a header file to inform them of what the
    others have that they need, including `Node.h` which defines the data-structure. Please finish both the `main.c`
    and `headers.h`

- Please make `print()` print the whole linked list.
- For `headers.h`, not everything needs to be shared.
    - `main()` needs `insertionSort()` and `mergeSortWrapper()`
    - Both `insertionSort()` and `mergeSortWrapper()` need
      `print()`.

  Otherwise, it is best *not* to share too much, kind of like keeping methods and members `private` in C++ and Java.

##### headers.h

```c
/*--------------------------------------------------------------------------*
 *----									----*
 *----		headers.h						----*
 *----									----*
 *----	    This file declares common headers used through-out the	----*
 *----	the singly-linked list sorting program.				----*
 *----									----*
 *----	----	----	----	----	----	----	----	----	----*
 *----									----*
 *----	Version 1a					Joseph Phillips	----*
 *----									----*
 *--------------------------------------------------------------------------*/

#include	<stdlib.h>
#include	<stdio.h>
#include	"Node.h"

void print(const struct Node *nodePtr);
struct Node *mergeSortWrapper(struct Node *nodePtr);
struct Node *insertionSort(struct Node *nodePtr);
```

##### Node.h

```c
/*--------------------------------------------------------------------------*
 *----									----*
 *----		Node.h							----*
 *----									----*
 *----	    This file declares the struct that stores an integer and	----*
 *----	a next-pointer to implement a node in a singly-linked list.	----*
 *----									----*
 *----	----	----	----	----	----	----	----	----	----*
 *----									----*
 *----	Version 1a					Joseph Phillips	----*
 *----									----*
 *--------------------------------------------------------------------------*/

struct Node {
    int value_;
    struct Node *nextPtr_;
};
```

##### main.c

```c
/*--------------------------------------------------------------------------*
 *----									----*
 *----		main.c							----*
 *----									----*
 *----	    This file defines the main functions for a program that	----*
 *----	sorts a linked list of randomly-generated integers.		----*
 *----									----*
 *----	----	----	----	----	----	----	----	----	----*
 *----									----*
 *----	Version 1a					Joseph Phillips	----*
 *----									----*
 *--------------------------------------------------------------------------*/

#include    "headers.h"

#define        TEXT_LEN    256
#define        NUM_NUMBERS    (2*65536)

int numNumbers = NUM_NUMBERS;


//  PURPOSE:  To create and return the address of the first node of a linked
//	list of 'length' struct Node instances, each with a randomly-generated
//	integer in its 'value_' member variable.
struct Node *createList(int length) {
    if (length == 0) {
        return (NULL);
    }

    struct Node *startPtr = (struct Node *) malloc(sizeof(struct Node));
    struct Node *endPtr = startPtr;

    startPtr->value_ = rand() % 4096;
    startPtr->nextPtr_ = NULL;

    for (length--; length > 0; length--) {
        endPtr->nextPtr_ = (struct Node *) malloc(sizeof(struct Node));
        endPtr->nextPtr_->value_ = rand() % 4096;
        endPtr->nextPtr_->nextPtr_ = NULL;
        endPtr = endPtr->nextPtr_;
    }

    return (startPtr);
}


//  PURPOSE:  To print integer values in the linked list pointed to by
//	'nodePtr'.  No return value.
void print(const struct Node *nodePtr) {
    for (int i = 0; nodePtr != NULL; i++, nodePtr = nodePtr->nextPtr_) {
        if (i % 8 == 0) printf("\n");
        printf("%8d", nodePtr->value_);
    }
    printf("\n");
}


//  PURPOSE:  To 'free()' the 'struct Node' instances of the linked list
//	pointed to by 'nodePtr'.  No return value.
void freeList(struct Node *nodePtr) {
    struct Node *nextPtr;

    for (; nodePtr != NULL; nodePtr = nextPtr) {
        nextPtr = nodePtr->nextPtr_;
        free(nodePtr);
    }

}


//  PURPOSE:  To run this program.  Ignores command line arguments.  Returns
//	'EXIT_SUCCESS' to OS.
int main() {
    int choice;
    struct Node *nodePtr = createList(numNumbers);

    print(nodePtr);

    do {
        char text[TEXT_LEN];

        printf("How do you want to sort %d numbers?\n"
               "(1) Insertion sort\n"
               "(2) Merge sort\n"
               "Your choice (1 or 2)? ", NUM_NUMBERS);
        fgets(text, TEXT_LEN, stdin);
        choice = strtol(text, NULL, 10);
    } while ((choice < 1) || (choice > 2));

    switch (choice) {
        case 1 :
            nodePtr = insertionSort(nodePtr);
            break;
        case 2 :
            nodePtr = mergeSortWrapper(nodePtr);
            break;
    }

    freeList(nodePtr);
    return (EXIT_SUCCESS);
}	  
```

#### Sample Initial Output

```shell
$ ./assign1 
...
53  1936    2909    151 65  2884    3534    3826    1564    2806
1611    640 2004    751 3304    3327    1724    1759    2947    1425
2399    1488    1365    2425    2998    2945    1864    392 3813    3099
1013    3966    939 3923    21  1004    2711    3555    734 180
2265    2346    820 173 
How do you want to sort 65536 numbers?
(1) Insertion sort
(2) Merge sort
Your choice (1 or 2)? 2
...
4093    4093    4093    4093    4093    4093    4093    4093    4093    4093
4093    4093    4093    4094    4094    4094    4094    4094    4094    4094
4094    4094    4094    4094    4094    4094    4094    4095    4095    4095
4095    4095    4095    4095    4095    4095    4095    4095    4095    4095
4095
```  

3.  #### Timing: Part 1 (20 Points):

Compile and run the program without any extra optimizations, but with *profiling* for timing:

```shell
$ gcc -c -pg -O0 main.c
$ gcc -c -pg -O0 mergeSort.c
$ gcc -c -pg -O0 insertionSort.c
$ gcc main.o mergeSort.o insertionSort.o -pg -O0 -o assign1-0
```

*Run the program twice* timing it both times, and answer the following:

1.  *How many **self seconds** did `insertionSort()` take?*

```shell
$ gprof assign1-0

Flat profile:

Each sample counts as 0.01 seconds.
  %   cumulative   self              self     total           
 time   seconds   seconds    calls   s/call   s/call  name    
100.51     29.43    29.43        1    29.43    29.44  insertionSort
  0.07     29.45     0.02        2     0.01     0.01  print
  0.03     29.46     0.01        1     0.01     0.01  freeList
  0.00     29.46     0.00        1     0.00     0.00  createList
```

b.  *How many **self seconds** did `mergeSort()` take?*

```shell
$ gprof assign1-0

Flat profile:

Each sample counts as 0.01 seconds.
  %   cumulative   self              self     total           
 time   seconds   seconds    calls  ms/call  ms/call  name    
 75.46      0.03     0.03        1    30.18    30.18  mergeSort
 25.15      0.04     0.01        1    10.06    10.06  freeList
  0.00      0.04     0.00        2     0.00     0.00  print
  0.00      0.04     0.00        1     0.00     0.00  createList
  0.00      0.04     0.00        1     0.00    30.18  mergeSortWrapper
```

4.  #### Timing: Part 2 (20 Points):

Compile and run the program *with* optimization, but with
*profiling* for timing:

```shell
$ gcc -c -pg -O2 main.c
$ gcc -c -pg -O2 mergeSort.c
$ gcc -c -pg -O2 insertionSort.c
$ gcc main.o mergeSort.o insertionSort.o -pg -O2 -o assign1-2
```

*Run the program twice* timing it both times, and answer the following:

1.  *How many **self seconds** did `insertionSort()` take?*

```shell
$ gprof assign1-2
Flat profile:

Each sample counts as 0.01 seconds.
  %   cumulative   self              self     total           
 time   seconds   seconds    calls  Ts/call  Ts/call  name    
100.55     29.20    29.20                             insertionSort
  0.07     29.22     0.02                             print
```

2. *How many **self seconds** did `mergeSort()` take?*

```shell
$ gprof assign1-2

Flat profile:

Each sample counts as 0.01 seconds.
  %   cumulative   self              self     total           
 time   seconds   seconds    calls  Ts/call  Ts/call  name    
 92.24      0.11     0.11                             mergeSort
  8.39      0.12     0.01                             print
```

5.  #### Human vs. Compiler Optimization (10 Points):

Which is faster:

- A bad algorithm and data-structure optimized with -O2
- A good algorithm and data-structure optimized with -O0

> A good algorithm optimized with -O0 is much faster

> A good algorithm with better O(n) complexity is always much faster than 
> (unless the complexity between algorithms is like difference between O($2^n$) 
> or O(n!) in which case it depends on the size of dataset). The reason is the
> compiler optimization is always oriented towards improvements of memory 
> allocations, branch/loop optimizations and better architectural instructions. So
> in most cases, a bad algorithms will have the same path regardless of the optimizations
> However, JIT languages like Java can allow better performances due to runtime
> compilation and condition skipping during the actual execution.

6.  #### Parts of an executable (Points 20):

Please find the following inside of `assign1-0` by using `objdump`.

- If it *can* be found then *both*
    1. Give the `objdump` command, and
    2. Show the `objdump` result
- If it *cannot* be found then tell why not. Where in the memory of the runtime process is it?

Look for:

1. Global integer `numNumbers` in `main.c`

```shell
$ objdump -D assign1-0

0000000000001389 <main>:
    1389:	55                   	push   %rbp
    138a:	48 89 e5             	mov    %rsp,%rbp
    138d:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
    1394:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    139b:	00 00 
    139d:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
    13a1:	31 c0                	xor    %eax,%eax
    13a3:	8b 05 cf 2c 00 00    	mov    0x2ccf(%rip),%eax        # 4078 <numNumbers>

0000000000004078 <numNumbers>:
    4078:	00 00                	add    %al,(%rax)
    407a:	02 00                	add    (%rax),%al
```

2. The string constant in `main()`

```shell
$  objdump -s -j .rodata assign1-0

node:     file format elf64-x86-64

Contents of section .rodata:
 2000 01000200 00000000 25386400 00000000  ........%8d.....
 2010 486f7720 646f2079 6f752077 616e7420  How do you want 
 2020 746f2073 6f727420 2564206e 756d6265  to sort %d numbe
 2030 72733f0a 28312920 496e7365 7274696f  rs?.(1) Insertio
 2040 6e20736f 72740a28 3229204d 65726765  n sort.(2) Merge
 2050 20736f72 740a596f 75722063 686f6963   sort.Your choic
 2060 65202831 206f7220 32293f20 00        e (1 or 2)? .   
```

3. The code for `print()`
```shell
$ objdump -D assign1-0 

00000000000012e7 <print>:
    12e7:	55                   	push   %rbp
    12e8:	48 89 e5             	mov    %rsp,%rbp
    12eb:	48 83 ec 20          	sub    $0x20,%rsp
    12ef:	48 89 7d e8          	mov    %rdi,-0x18(%rbp)
    12f3:	c7 45 fc 00 00 00 00 	movl   $0x0,-0x4(%rbp)
    12fa:	eb 40                	jmp    133c <print+0x55>
    12fc:	8b 45 fc             	mov    -0x4(%rbp),%eax
    12ff:	83 e0 07             	and    $0x7,%eax
    1302:	85 c0                	test   %eax,%eax
    1304:	75 0a                	jne    1310 <print+0x29>
    1306:	bf 0a 00 00 00       	mov    $0xa,%edi
    130b:	e8 30 fd ff ff       	call   1040 <putchar@plt>
    1310:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
    1314:	8b 00                	mov    (%rax),%eax
    1316:	89 c6                	mov    %eax,%esi
    1318:	48 8d 05 e9 0c 00 00 	lea    0xce9(%rip),%rax        # 2008 <_IO_stdin_used+0x8>
    131f:	48 89 c7             	mov    %rax,%rdi
    1322:	b8 00 00 00 00       	mov    $0x0,%eax
    1327:	e8 34 fd ff ff       	call   1060 <printf@plt>
    132c:	83 45 fc 01          	addl   $0x1,-0x4(%rbp)
    1330:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
    1334:	48 8b 40 08          	mov    0x8(%rax),%rax
    1338:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
    133c:	48 83 7d e8 00       	cmpq   $0x0,-0x18(%rbp)
    1341:	75 b9                	jne    12fc <print+0x15>
    1343:	bf 0a 00 00 00       	mov    $0xa,%edi
    1348:	e8 f3 fc ff ff       	call   1040 <putchar@plt>
    134d:	90                   	nop
    134e:	c9                   	leave  
    134f:	c3                   	ret    


0000000000001389 <main>:
    1389:	55                   	push   %rbp
    138a:	48 89 e5             	mov    %rsp,%rbp
    138d:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
    1394:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    139b:	00 00 
    139d:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
    13a1:	31 c0                	xor    %eax,%eax
    13a3:	8b 05 cf 2c 00 00    	mov    0x2ccf(%rip),%eax        # 4078 <numNumbers>
    13a9:	89 c7                	mov    %eax,%edi
    13ab:	e8 79 fe ff ff       	call   1229 <createList>
    13b0:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
    13b7:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
    13be:	48 89 c7             	mov    %rax,%rdi
    13c1:	e8 21 ff ff ff       	call   12e7 <print>
    13c6:	be 00 00 02 00       	mov    $0x20000,%esi
    13cb:	48 8d 05 3e 0c 00 00 	lea    0xc3e(%rip),%rax        # 2010 <_IO_stdin_used+0x10>
    13d2:	48 89 c7             	mov    %rax,%rdi
    13d5:	b8 00 00 00 00       	mov    $0x0,%eax
    13da:	e8 81 fc ff ff       	call   1060 <printf@plt>
    13df:	48 8b 15 9a 2c 00 00 	mov    0x2c9a(%rip),%rdx        # 4080 <stdin@@GLIBC_2.2.5>
    13e6:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
```

The address for print method `12e7`.

4. The int variable `choice` in `main()`


```shell
$ objdump -D assign1-0

0000000000001389 <main>:
    1389:	55                   	push   %rbp
    138a:	48 89 e5             	mov    %rsp,%rbp
    138d:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
    1394:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    139b:	00 00 
    139d:	48 89 45 f8          	mov    %rax,-0x8(%rbp)

```

At instruction `139d`, we are allocating 8 bytes on the stack. The compiler doesn't add the 
name of the variable in the object file so this is an assumption since before the stack pointer
movement, there is stack guard check and after this we are copying the numNumber so that we
can pass it to the createList as argument.

7.  #### Compiler optimizations (Points 10):

Look at the assembly code of `assign1-0` and `assign1-2`. *Find* and
*show* at least **2** optimizations that the compiler did in either
`assign1-2` or `assign1-0`.

##### Output of objdump of assign1-0

```shell
$ objdump -D assign-O0
0000000000001447 <main>:
    1447:	55                   	push   %rbp
    1448:	48 89 e5             	mov    %rsp,%rbp
    144b:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
    1452:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    1459:	00 00
    145b:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
    145f:	31 c0                	xor    %eax,%eax
    1461:	8b 05 01 2c 00 00    	mov    0x2c01(%rip),%eax        # 4068 <numNumbers>
    1467:	89 c7                	mov    %eax,%edi
    1469:	e8 79 fe ff ff       	call   12e7 <createList>
    146e:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
    1475:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
    147c:	48 89 c7             	mov    %rax,%rdi
    147f:	e8 21 ff ff ff       	call   13a5 <print>
    1484:	be 00 00 02 00       	mov    $0x20000,%esi
    1489:	48 8d 05 80 0b 00 00 	lea    0xb80(%rip),%rax        # 2010 <_IO_stdin_used+0x10>
    1490:	48 89 c7             	mov    %rax,%rdi
    1493:	b8 00 00 00 00       	mov    $0x0,%eax
    1498:	e8 c3 fb ff ff       	call   1060 <printf@plt>
    149d:	48 8b 15 cc 2b 00 00 	mov    0x2bcc(%rip),%rdx        # 4070 <stdin@@GLIBC_2.2.5>
    14a4:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    14ab:	be 00 01 00 00       	mov    $0x100,%esi
    14b0:	48 89 c7             	mov    %rax,%rdi
    14b3:	e8 b8 fb ff ff       	call   1070 <fgets@plt>
    14b8:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    14bf:	ba 0a 00 00 00       	mov    $0xa,%edx
    14c4:	be 00 00 00 00       	mov    $0x0,%esi
    14c9:	48 89 c7             	mov    %rax,%rdi
    14cc:	e8 af fb ff ff       	call   1080 <strtol@plt>
    14d1:	89 85 e4 fe ff ff    	mov    %eax,-0x11c(%rbp)
    14d7:	83 bd e4 fe ff ff 00 	cmpl   $0x0,-0x11c(%rbp)
    14de:	7e a4                	jle    1484 <main+0x3d>
    14e0:	83 bd e4 fe ff ff 02 	cmpl   $0x2,-0x11c(%rbp)
    14e7:	7f 9b                	jg     1484 <main+0x3d>
    14e9:	83 bd e4 fe ff ff 01 	cmpl   $0x1,-0x11c(%rbp)
    14f0:	74 0b                	je     14fd <main+0xb6>
    14f2:	83 bd e4 fe ff ff 02 	cmpl   $0x2,-0x11c(%rbp)
    14f9:	74 1a                	je     1515 <main+0xce>
    14fb:	eb 2f                	jmp    152c <main+0xe5>
    14fd:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
    1504:	48 89 c7             	mov    %rax,%rdi
    1507:	e8 9d fc ff ff       	call   11a9 <insertionSort>
    150c:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
    1513:	eb 17                	jmp    152c <main+0xe5>
    1515:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
    151c:	48 89 c7             	mov    %rax,%rdi
    151f:	e8 d5 01 00 00       	call   16f9 <mergeSortWrapper>
    1524:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
    152b:	90                   	nop
    152c:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
    1533:	48 89 c7             	mov    %rax,%rdi
    1536:	e8 d3 fe ff ff       	call   140e <freeList>
    153b:	b8 00 00 00 00       	mov    $0x0,%eax
    1540:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
    1544:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    154b:	00 00
    154d:	74 05                	je     1554 <main+0x10d>
    154f:	e8 fc fa ff ff       	call   1050 <__stack_chk_fail@plt>
    1554:	c9                   	leave
    1555:	c3                   	ret
```

##### Output of objdump of assign1-2

```shell
$ objdump -D assign-O2
00000000000010b0 <main>:
    10b0:	41 54                	push   %r12
    10b2:	4c 8d 25 4f 0f 00 00 	lea    0xf4f(%rip),%r12        # 2008 <_IO_stdin_used+0x8>
    10b9:	55                   	push   %rbp
    10ba:	53                   	push   %rbx
    10bb:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    10c2:	8b 3d a0 2f 00 00    	mov    0x2fa0(%rip),%edi        # 4068 <numNumbers>
    10c8:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    10cf:	00 00 
    10d1:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    10d8:	00 
    10d9:	31 c0                	xor    %eax,%eax
    10db:	48 89 e3             	mov    %rsp,%rbx
    10de:	e8 9d 02 00 00       	call   1380 <createList>
    10e3:	48 89 c7             	mov    %rax,%rdi
    10e6:	48 89 c5             	mov    %rax,%rbp
    10e9:	e8 22 03 00 00       	call   1410 <print>
    10ee:	66 90                	xchg   %ax,%ax
    10f0:	be 00 00 02 00       	mov    $0x20000,%esi
    10f5:	4c 89 e7             	mov    %r12,%rdi
    10f8:	31 c0                	xor    %eax,%eax
    10fa:	e8 61 ff ff ff       	call   1060 <printf@plt>
    10ff:	48 8b 15 6a 2f 00 00 	mov    0x2f6a(%rip),%rdx        # 4070 <stdin@@GLIBC_2.2.5>
    1106:	be 00 01 00 00       	mov    $0x100,%esi
    110b:	48 89 df             	mov    %rbx,%rdi
    110e:	e8 5d ff ff ff       	call   1070 <fgets@plt>
    1113:	ba 0a 00 00 00       	mov    $0xa,%edx
    1118:	31 f6                	xor    %esi,%esi
    111a:	48 89 df             	mov    %rbx,%rdi
    111d:	e8 5e ff ff ff       	call   1080 <strtol@plt>
    1122:	8d 50 ff             	lea    -0x1(%rax),%edx
    1125:	83 fa 01             	cmp    $0x1,%edx
    1128:	77 c6                	ja     10f0 <main+0x40>
    112a:	83 f8 01             	cmp    $0x1,%eax
    112d:	74 4b                	je     117a <main+0xca>
    112f:	83 f8 02             	cmp    $0x2,%eax
    1132:	75 20                	jne    1154 <main+0xa4>
    1134:	48 89 ef             	mov    %rbp,%rdi
    1137:	e8 d4 04 00 00       	call   1610 <mergeSortWrapper>
    113c:	48 89 c5             	mov    %rax,%rbp
    113f:	eb 13                	jmp    1154 <main+0xa4>
    1141:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1148:	48 89 ef             	mov    %rbp,%rdi
    114b:	48 8b 6d 08          	mov    0x8(%rbp),%rbp
    114f:	e8 dc fe ff ff       	call   1030 <free@plt>
    1154:	48 85 ed             	test   %rbp,%rbp
    1157:	75 ef                	jne    1148 <main+0x98>
    1159:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    1160:	00 
    1161:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    1168:	00 00 
    116a:	75 1b                	jne    1187 <main+0xd7>
    116c:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    1173:	31 c0                	xor    %eax,%eax
    1175:	5b                   	pop    %rbx
    1176:	5d                   	pop    %rbp
    1177:	41 5c                	pop    %r12
    1179:	c3                   	ret    
    117a:	48 89 ef             	mov    %rbp,%rdi
    117d:	e8 0e 01 00 00       	call   1290 <insertionSort>
    1182:	48 89 c5             	mov    %rax,%rbp
    1185:	eb cd                	jmp    1154 <main+0xa4>
    1187:	e8 c4 fe ff ff       	call   1050 <__stack_chk_fail@plt>
    118c:	0f 1f 40 00          	nopl   0x0(%rax)
```

##### Difference

The differences are as follows:

1. Number of jump calls after conditions have been reduced, 3 in -O2 vs 4 in -O0 and 
many instructions have been removed, decreasing the total number of instructions.
2. The stack pointer register is omitted and relative addresses are used that allows
the functions to use `rbp` as another general purpose register.
 