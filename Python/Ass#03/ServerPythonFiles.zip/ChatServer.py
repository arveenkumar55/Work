import socket
import sys
import threading
from threading import Thread
from typing import List, Dict

import network
from network import Request, Command, ClientInfo

lock = threading.Lock()
clients: Dict[str, ClientInfo] = {}
commands: List[Command] = []


class ServerResponseThread(Thread):
    soc: socket.socket
    __commands: List[Command]

    def __init__(self, soc: socket.socket) -> None:
        super().__init__(daemon=True)
        self.soc = soc
        self.__commands = []

    def run(self) -> None:
        while True:
            queued = [command for command in commands if command not in self.__commands]
            if len(queued) != 0:
                for command in queued:
                    if command.type == Request.FILE:
                        pass
                    elif command.type == Request.MESSAGE:
                        network.send_request(self.soc, network.encode_parameter(command.json()))

                    self.__commands.append(command)

    def append(self, command: Command) -> None:
        self.__commands.append(command)


class ServerThread(Thread):
    soc: socket.socket
    client_name: str = ''
    response_thread: ServerResponseThread

    def __init__(self, soc: socket.socket):
        super().__init__(daemon=True)
        self.soc = soc
        self.response_thread = ServerResponseThread(soc)

    def start(self) -> None:
        super().start()
        self.response_thread.start()

    def run(self) -> None:
        while True:
            data = network.get_request(self.soc)
            if data is None:
                continue

            command = Command.parse_json(network.decode_parameter(data)[0])
            if command.type == Request.EXIT:
                clients.pop(self.client_name)
                break
            elif command.type == Request.ASSIGN:
                info = ClientInfo.parse_json(command.contents)
                self.client_name = info.name
                clients[self.client_name] = info
                continue
            elif command.type == Request.FILE:
                peer_client = clients[command.contents]
                network.send_request(self.soc, network.encode_parameter(
                    Command("server", Request.FILE.value, str(peer_client.listen)).json()
                ))
                continue

            self.response_thread.append(command)
            commands.append(command)


class Server:
    soc: socket.socket
    queue: List[str]

    def on_create(self) -> None:
        print("Local IP Address:", network.get_local_ip())
        print()
        print("Press any key to continue")

    def __init__(self, port: int) -> None:
        # self.on_create()
        self.soc = network.create_server_connection(network.get_local_ip(), port)

    def start(self) -> None:
        while True:
            self.soc.listen()
            if self.soc:
                conn, _ = self.soc.accept()
                ServerThread(conn).start()


if __name__ == '__main__':
    Server(int(sys.argv[1])).start()
