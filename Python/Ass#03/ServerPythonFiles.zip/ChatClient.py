import argparse
import socket
from random import random
from threading import Thread
from typing import List

import network
from network import Request, Command, ClientInfo

prompt = """Enter an option ('m', 'f', 'x'):
  (M)essage (send)
  (F)ile (request)
  e(X)it\n"""

responses: List[Command] = []


class FileClientTransfer(Thread):
    soc: socket.socket
    file: str
    name: str
    port: int

    def __init__(self, name: str, file: str, port: int) -> None:
        super().__init__()
        self.soc = network.create_connection(network.get_local_ip(), port)
        self.file = file
        self.name = name
        self.port = port

    def run(self) -> None:
        self.send_request(Request.FILE, self.file)
        with open(self.file, "wb") as f:
            data = network.get_request(self.soc)
            while data is None:
                data = network.get_request(self.soc)

            f.write(data)

    def send_request(self, type: Request, contents: str) -> None:
        network.send_request(self.soc, network.encode_parameter(
            Command(self.name, type.value, contents).json()
        ))


class FileServerTransfer(Thread):
    soc: socket.socket
    file: str

    def __init__(self, soc: socket.socket, file: str) -> None:
        super().__init__(daemon=True)
        self.soc = soc
        self.file = file

    def run(self) -> None:
        with open(self.file, 'rb') as f:
            network.send_request(self.soc, f.read())


class FileServer(Thread):
    soc: socket.socket
    port: int

    def __init__(self, port: int) -> None:
        super().__init__(daemon=True)
        self.soc = network.create_server_connection(network.get_local_ip(), port)
        self.port = port

    def run(self) -> None:
        while True:
            self.soc.listen()
            if self.soc:
                conn, _ = self.soc.accept()
                data = self.get_request(conn)
                FileServerTransfer(conn, data.contents).start()

    def get_request(self, conn: socket.socket = None) -> Command:
        soc = conn or self.soc
        data = network.get_request(soc)
        while data is None:
            data = network.get_request(soc)

        return Command.parse_json(network.decode_parameter(data)[0])


class ClientOutput(Thread):
    soc: socket.socket

    def __init__(self, soc: socket.socket) -> None:
        super().__init__(daemon=True)
        self.soc = soc

    def run(self) -> None:
        while True:
            data = network.get_request(self.soc)
            if data is None:
                continue

            command = Command.parse_json(network.decode_parameter(data)[0])
            if command.type == Request.MESSAGE:
                print(f"{command.sender}: {command.contents}")
            else:
                responses.append(command)


class Client:
    name: str
    ip: str
    port: int
    soc: socket.socket

    def __init__(self, ip: str, port: int, listen: int) -> None:
        self.ip = ip
        self.port = port

        FileServer(listen).start()
        self.soc = network.create_connection(ip, port)
        self.name = input()
        self.send_request(Request.ASSIGN, ClientInfo(self.name, listen).json())

    def start(self) -> None:
        output = ClientOutput(self.soc)
        output.start()
        option = Client.show_prompt()
        while option != Request.EXIT:
            if option == Request.MESSAGE:
                self.send_message()
            elif option == Request.FILE:
                self.get_file()

            option = Client.show_prompt()

        self.send_request(Request.EXIT, '')
        self.soc.close()

    @staticmethod
    def show_prompt() -> Request:
        option = input()

        if option not in Request.user():
            print(f"Invalid option selected: {option}")
            return Client.show_prompt()

        return Request(option)

    def send_message(self) -> None:
        message = input()
        self.send_request(Request.MESSAGE, message)

    def get_file(self) -> None:
        client = input()
        self.send_request(Request.FILE, client)
        while len(responses) == 0:
            pass

        port = int(responses.pop().contents)
        file = input()
        FileClientTransfer(self.name, file, port).start()

    def get_request(self) -> Command:
        return Command.parse_json(network.decode_parameter(network.get_request(self.soc))[0])

    def send_request(self, type: Request, contents: str) -> None:
        network.send_request(self.soc, network.encode_parameter(
            Command(self.name, type.value, contents).json()
        ))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-p')
    parser.add_argument('-l')
    args = parser.parse_args()
    log = open(f"/tmp/error-{random()}.log", "w")
    Client(network.get_local_ip(), int(args.p), int(args.l)).start()
    log.close()
