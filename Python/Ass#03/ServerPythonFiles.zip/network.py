import json
import socket
import struct
from enum import Enum
from time import sleep
from typing import Optional, Sequence, Callable, Dict

from nullsafe import is_not_none


def get_local_ip() -> str:
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        try:
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
        except Exception as e:
            ip = "127.0.0.1"
    return ip


def create_server_connection(ip: str, port: int) -> socket.socket:
    soc = socket.socket()
    soc.bind((ip, port))
    return soc


def create_connection(ip: str, port: int) -> Optional[socket.socket]:
    soc = socket.socket()
    try:
        soc.connect((ip, port))
    except ConnectionRefusedError as e:
        return None
    return soc


def recv_bytes(
        soc: socket.socket,
        size: int,
        wait: bool = True,
        retries: int = 3,
        progress: Optional[Callable[[int, int, int], None]] = None
) -> Optional[bytearray]:
    data = bytearray()
    while len(data) < size:
        packet: Optional[bytes] = None
        try:
            packet = soc.recv(size - len(data))
            if progress is not None:
                progress(len(data), size, len(packet))
        except OSError as e:
            if wait:
                retries -= 1
                sleep(0.1)
            else:
                raise e
        if packet is None or packet == b'' or retries <= 0:
            return None
        data.extend(packet)
    return data


def encode_parameter(*param: str) -> bytes:
    return "::".join(param).encode("utf-8")


def decode_parameter(param: bytes) -> Sequence[str]:
    return param.decode("utf-8").split("::")


def get_request(soc: socket.socket,
                progress: Optional[Callable[[int, int, int], None]] = None) -> Optional[bytes]:
    try:
        size = struct.unpack("I", is_not_none(recv_bytes(soc, 4)))
        return bytes(is_not_none(recv_bytes(soc, size[0], progress=progress)))
    except (TypeError, AssertionError):
        return None


def send_request(soc: socket.socket, param: bytes) -> None:
    try:
        soc.sendall(struct.pack("I", len(param)) + param)
    except OSError:
        pass


class Request(Enum):
    MESSAGE = 'm'
    FILE = 'f'
    ASSIGN = 'a'
    EXIT = 'x'

    @classmethod
    def user(cls):
        return [Request.MESSAGE.value, Request.FILE.value, Request.EXIT.value]


class ClientInfo:
    name: str
    listen: int

    def __init__(self, name: str, listen: int) -> None:
        self.name = name
        self.listen = listen

    def dict(self) -> Dict[str, str]:
        return {
            "name": self.name,
            "listen": self.listen
        }

    def json(self) -> str:
        return json.dumps(self.dict())

    @staticmethod
    def parse_obj(_dict: Dict[str, str]) -> 'ClientInfo':
        return ClientInfo(**_dict)

    @staticmethod
    def parse_json(_json: str) -> 'ClientInfo':
        return ClientInfo(**json.loads(_json))


class Command:
    sender: str
    type: Request
    contents: str

    def __init__(self, sender: str, type: str, contents: str) -> None:
        self.sender = sender
        self.type = Request(type)
        self.contents = contents

    def dict(self) -> Dict[str, str]:
        return {
            "sender": self.sender,
            "type": self.type.value,
            "contents": self.contents
        }

    def json(self) -> str:
        return json.dumps(self.dict())

    @staticmethod
    def parse_obj(_dict: Dict[str, str]) -> 'Command':
        return Command(**_dict)

    @staticmethod
    def parse_json(_json: str) -> 'Command':
        return Command(**json.loads(_json))

    def __str__(self) -> str:
        return self.json()

    def __repr__(self) -> str:
        return self.json()
