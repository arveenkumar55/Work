from typing import Optional, TypeVar, Type

__T1 = TypeVar('__T1')
__T2 = TypeVar('__T2')


def is_not_none(value: Optional[__T1]) -> __T1:
    assert value is not None
    return value


def is_type(type_: Type[__T1], value: __T2) -> __T1:
    assert isinstance(value, type_), f'{type(value)} != {type_}'
    return value
