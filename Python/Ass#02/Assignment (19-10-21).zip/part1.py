def read_file(file_path):
    lines = []
    with open(file_path, encoding='utf-8') as f:
        lines = f.readlines()
    return lines

def get_words(row):
    words = []
    special_characters = """@#$%^&*()+~?_=⛅️❄️-·‰•–←→¡|★▲✦<>›…»«â€™/0123456789"""
    for x in row.split():
        word = x.replace(',', '').replace('.','').replace(':','').replace('!','').replace('[','').replace(']','').replace('"','').replace('“','').replace('”','').replace('—',' ').replace('‘','').replace("'",'').replace(';','').replace('®','').replace('(','').replace(')','')
        if not any(c in special_characters for c in word):
            words.append(word)
    return words

def count_occurrences(lst):
    dict = {}
    for i in lst:
        if len(i)>4:
            if i in dict.keys():
                dict[i]+=1
            else:
                dict.update({i:1})
    return dict


path = "find_word_output/"


file1 = 'output_1925084_words.txt'
input_list = read_file(path+file1)
words = []
for row in input_list:
    w = get_words(row)  # Returns a list of words
    words += w

# print(len(words))
# converting our list to set
set1 = set(words)
print("No of unique words in the "+file1+" are:", len(set1))
print('Count of occurences of numbers in '+file1+':')
sorted_dict = sorted(count_occurrences(words).items(), key = lambda item: item[1], reverse= True)
for i in range(10):
    print(sorted_dict[i])


file2 = 'output_10823_words.txt'
input_list = read_file(path+file2)
words = []
for row in input_list:
    w = get_words(row)  # Returns a list of words
    words += w

# print(len(words))
# converting our list to set
set2 = set(words)
print("No of unique words in the "+file2+" are:", len(set2))
print('Count of occurences of numbers in '+file1+':')
sorted_dict = sorted(count_occurrences(words).items(), key = lambda item: item[1], reverse= True)
for i in range(10):
    print(sorted_dict[i])
