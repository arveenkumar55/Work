import HashSet as hset
import BstMap as bst

def read_file(file_path):
    lines = []
    with open(file_path, encoding='utf-8') as f:
        lines = f.readlines()
    return lines

def get_words(row):
    words = []
    special_characters = """@#$%^&*()+~?_=⛅️❄️-·‰•–←→¡|★▲✦<>›…»«â€™/0123456789"""
    for x in row.split():
        word = x.replace(',', '').replace('.','').replace(':','').replace('!','').replace('[','').replace(']','').replace('"','').replace('“','').replace('”','').replace('—',' ').replace('‘','').replace("'",'').replace(';','').replace('®','').replace('(','').replace(')','')
        if not any(c in special_characters for c in word):
            words.append(word)
    return words

def count_occurrences(lst):
    dict = {}
    for i in lst:
        if len(i)>4:
            if i in dict.keys():
                dict[i]+=1
            else:
                dict.update({i:1})
    return dict
path = "find_word_output/"


file1 = 'output_1925084_words.txt'
input_list = read_file(path+file1)
words = []
for row in input_list:
    w = get_words(row)  # Returns a list of words
    words += w

wordHash = hset.HashSet()   # Create new empty HashSet
wordHash.init()
for word in words:
    wordHash.add(word)

print("No of unique words in the "+file1+" (using HashSet) are:", wordHash.get_size())
print('Count of occurences of numbers in '+file1+' (using HashSet):')
sorted_dict = sorted(count_occurrences(words).items(), key = lambda item: item[1], reverse= True)
for i in range(10):
    print(sorted_dict[i])
print('Maximum Hash Size: '+str(wordHash.max_bucket_size()))

map = bst.BstMap()
for word in words:
    if map.get(word) is None:
        map.put(word, 1)
    else:
        map.put(word, map.get(word)+1)

print("No of unique words in the "+file1+" (using BstMap) are:", map.size())
print('Count of occurences of numbers in '+file1+' (using BstMap):')
sorted_dict = sorted(count_occurrences(words).items(), key = lambda item: item[1], reverse= True)
for i in range(10):
    print(sorted_dict[i])
print("Maximum depth of BST: "+str(map.max_depth()))


file2 = 'output_10823_words.txt'

input_list = read_file(path+file2)
words = []
for row in input_list:
    w = get_words(row)  # Returns a list of words
    words += w

wordHash = hset.HashSet()   # Create new empty HashSet
wordHash.init()
for word in words:
    wordHash.add(word)

print("No of unique words in the "+file2+" (using HashSet) are:", wordHash.get_size())
print('Count of occurences of numbers in '+file2+' (using HashSet):')
sorted_dict = sorted(count_occurrences(words).items(), key = lambda item: item[1], reverse= True)
for i in range(10):
    print(sorted_dict[i])
print('Maximum Hash Size: '+str(wordHash.max_bucket_size()))

map = bst.BstMap()
for word in words:
    if map.get(word) is None:
        map.put(word, 1)
    else:
        map.put(word, map.get(word)+1)

print("No of unique words in the "+file2+" (using BstMap) are:", map.size())
print('Count of occurences of numbers in '+file2+' (using BstMap):')
sorted_dict = sorted(count_occurrences(words).items(), key = lambda item: item[1], reverse= True)
for i in range(10):
    print(sorted_dict[i])
print("Maximum depth of BST: "+str(map.max_depth()))