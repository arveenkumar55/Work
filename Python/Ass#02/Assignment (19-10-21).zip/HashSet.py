from dataclasses import dataclass
from typing import List
import hashlib


@dataclass
class HashSet:
    buckets: List[List] = None
    size: int = 0

    def init(self):
        self.size = 0
        self.buckets = [[] for i in range(8)]

    # Computes hash value for a word (a string)
    def get_hash(self, word):
        return  int(hashlib.sha1(word.encode('utf-8')).hexdigest(), 16) % len(self.buckets)   # Placeholder code ==> to be replaced

    # Doubles size of bucket list
    def rehash(self):
        for i in range(8):
            self.buckets.append([])    # Placeholder code ==> to be replaced

    # Adds a word to set if not already added
    def add(self, word):
        hash = self.get_hash(word)
        if self.size>len(self.buckets):
            self.rehash()
        if not self.contains(word):
            self.buckets[hash].append(word)
            self.size+=1   # Placeholder code ==> to be replaced

    # Returns a string representation of the set content
    def to_string(self):
        string = '{ '
        for i in range(len(self.buckets)):
            for j in range(len(self.buckets[i])):
                string+= self.buckets[i][j]+' '
        string+= '}'
        return string    # Placeholder code ==> to be replaced

    # Returns current number of elements in set
    def get_size(self):
        return self.size    # Placeholder code ==> to be replaced

    # Returns True if word in set, otherwise False
    def contains(self, word):
        flag = False
        for i in self.buckets:
            if word in i:
                flag = True
                break    # Placeholder code ==> to be replaced
        return flag

    # Returns current size of bucket list
    def bucket_list_size(self):
        return len(self.buckets)    # Placeholder code ==> to be replaced

    # Removes word from set if there, does nothing
    # if word not in set
    def remove(self, word):
        if self.contains(word):
            hash = self.get_hash(word)
            if word in self.buckets[hash]:
                self.buckets[hash].remove(word)
                self.size-=1
            else:
                 for i in range(self.bucket_list_size()):
                    if self.buckets[i] == word:
                        self.buckets[i] == None
                        break    # Placeholder code ==> to be replaced
           # Placeholder code ==> to be replaced

    # Returns the size of the bucket with most elements
    def max_bucket_size(self):
        max = 0
        count = 0
        for i in self.buckets:
            for j in i:
                if not j is None:
                    count+=1
            if count > max:
                max = count
            count = 0
        return max    # Placeholder code ==> to be replaced
