import unittest
from main import BusinessLayer


class TestBusinessLayer(unittest.TestCase):

    def test_get_record(self):
        businessLayer = BusinessLayer()
        record = businessLayer.get_record("INC2008-009")
        self.assertEqual("INC2008-009", record.get_Incident_Number())
        self.assertEqual("Release of Substance, Adverse Environmental Effects", record.get_Incident_Types())
        self.assertEqual("01/29/2008", record.get_Reported_Date())
        self.assertEqual("Taylor", record.get_Nearest_Populated_Centre())
        self.assertEqual("British Columbia", record.get_Province())
        self.assertEqual("Westcoast Energy Inc., carrying on business as Spectra Energy Transmission", record.get_Company())
        self.assertEqual("Potassium Hydroxide (caustic solution)", record.get_Substance())
        self.assertEqual("Yes", record.get_Significant())
        self.assertEqual("Equipment Failure", record.get_What_happened_category())
