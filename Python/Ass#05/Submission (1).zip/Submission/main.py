#!/usr/bin/env python
# coding: utf-8

# In[19]:

import csv


class pipelineIncident:
    """Declaration of pipelineIncident class."""

    def __init__(self, Incident_Number, Incident_Types, Reported_Date, Nearest_Populated_Centre, Province, Company,
                 Substance, Significant, What_happened_category):
        self.Incident_Number = Incident_Number
        self.Incident_Types = Incident_Types
        self.Reported_Date = Reported_Date
        self.Nearest_Populated_Centre = Nearest_Populated_Centre
        self.Province = Province
        self.Company = Company
        self.Substance = Substance
        self.Significant = Significant
        self.What_happened_category = What_happened_category

    def get_Incident_Number(self):
        """Return Incident Number."""
        return self.Incident_Number

    def set_Incident_Number(self, a):
        """Set Incident Number."""

        self.Incident_Number = a

    def get_Incident_Types(self):
        """Set Incident Types."""
        return self.Incident_Types

    def set_Incident_Types(self, a):
        """Set Incident Types."""

        self.Incident_Types = a

    def get_Reported_Date(self):
        """Get Reported Date."""

        return self.Reported_Date

    def set_Reported_Date(self, a):
        """Set Reported Date."""
        self.Reported_Date = a

    def get_Nearest_Populated_Centre(self):
        """get _Nearest_Populated_Centre."""
        return self.Nearest_Populated_Centre

    def set_Nearest_Populated_Centre(self, a):
        """set _Nearest_Populated_Centre."""
        self.Nearest_Populated_Centre = a

    def get_Province(self):
        """to get_Province."""
        return self.Province

    def set_Province(self, a):
        """to set_Province."""
        self.Province = a

    def get_Company(self):
        """to get_Company."""
        return self.Company

    def set_Company(self, a):
        """to set_Company."""
        self.Company = a

    def get_Substance(self):
        """to get_Substance ."""
        return self.Substance

    def set_Substance(self, a):
        """to set_Substance."""
        self.Substance = a

    def get_Significant(self):
        """to get_Significant ."""
        return self.Significant

    def set_Significant(self, a):
        """to set_Significant ."""
        self.Significant = a

    def get_What_happened_category(self):
        """to get_What_happened_category ."""
        return self.What_happened_category

    def set_What_happened_category(self, a):
        """to set_What_happened_category ."""
        self.What_happened_category = a

    def to_csv_format(self):
        return '{0},{1},{2},{3},{4},{5},{6},{7},{8}'.format(self.Incident_Number, self.Incident_Types, self.Reported_Date, self.Nearest_Populated_Centre, self.Province, self.Company, self.Substance, self.Significant, self.What_happened_category)


class PersistenceLayer:
    """Persistence layers handles the loading/saving of records"""
    def __init__(self, filename):
        """Constructor"""
        self.__filename = filename
        self.__pipelineIncidentList = list()
        self.__load_data_from_file()

    def __load_data_from_file(self, number_of_records=100):
        """Loads data from file into list"""
        try:  # handle exception
            with open(self.__filename, 'rt') as f:  # read file from dataset
                csv_reader = csv.reader(f)

                next(csv_reader)  # skip the heading
                current_count = 0
                for line in csv_reader:  # save data into List
                    for i in range(len(line)):
                        line[i] = line[i].replace('"', '')
                    self.__pipelineIncidentList.append(
                        pipelineIncident(line[0], line[1], line[2], line[3], line[4], line[5], line[10], line[12],
                                         line[17]))
                    current_count += 1
                    if current_count == number_of_records:
                        break
        except FileNotFoundError:
            print('File not found!!')
            # If any other error occurs, print the file name
        except Exception as e:
            print('Another Error!!')

    def reload(self):
        """Reloads the data from the file into the list"""
        self.__pipelineIncidentList.clear()
        self.__load_data_from_file()

    def persist(self):
        """Saves the records into a new csv file"""
        try:
            with open('pipeline-incidents-comprehensive-data2.csv', 'w+') as f:
                for incident in self.__pipelineIncidentList:
                    f.write(incident.to_csv_format() + "\n")
        except Exception as e:
            print('Another Error!!')
            print(e)

    def get_records(self):
        """Returns the list of all incident records"""
        return self.__pipelineIncidentList


class BusinessLayer:
    """Business layer handles all the business logic"""
    def __init__(self):
        """Constructor"""
        self.__persistenceLayer = PersistenceLayer("pipeline-incidents-comprehensive-data.csv")

    def reload_data(self):
        """Reloads the records"""
        self.__persistenceLayer.reload()

    def persist(self):
        """Saves all the records"""
        self.__persistenceLayer.persist()

    def get_record(self, incident_number):
        """Returns a record with the matching incident number"""
        for record in self.__persistenceLayer.get_records():
            if record.get_Incident_Number() == incident_number:
                return record

    def create_record(self, incident_number, incident_type, reported_date, nearest_populated_centre, province, company, substance, significant, what_happened_category):
        """Creates a new record"""
        self.__persistenceLayer.get_records().append(pipelineIncident(incident_number, incident_type, reported_date, nearest_populated_centre, province, company, substance, significant, what_happened_category))

    def edit_record(self, incident_number, incident_type, reported_date, nearest_populated_centre, province, company,
                      substance, significant, what_happened_category):
        """Edits an existing record"""
        for incident in self.__persistenceLayer.get_records():
            if incident.get_Incident_Number() == incident_number:
                incident.set_Incident_Types(incident_type)
                incident.set_Reported_Date(reported_date)
                incident.set_Nearest_Populated_Centre(nearest_populated_centre)
                incident.set_Province(province)
                incident.set_Company(company)
                incident.set_Substance(substance)
                incident.set_Significant(significant)
                incident.set_What_happened_category(what_happened_category)
                return True
        return False

    def delete_record(self, incident_number):
        """Deletes an existing record"""
        for incident in self.__persistenceLayer.get_records():
            if incident.get_Incident_Number() == incident_number:
                self.__persistenceLayer.get_records().remove(incident)
                return True
        return False


class PresentationLayer:
    """Presentation layer handles user interactions"""
    def __init__(self):
        """Constructor"""
        self.__businessLayer = BusinessLayer()

    def reload_dataset(self):
        """Allows the user to reload records from the file"""
        self.__businessLayer.reload_data()
        print("Pipeline incident records reloaded!")

    def persist_data(self):
        """Allows the user to save all the records to the file"""
        self.__businessLayer.persist()
        print("Pipeline incident records saved!")

    def select_record(self):
        """Allows user to select a record"""
        incident_number = input("Enter incident number: ")

        pipelineIncident = self.__businessLayer.get_record(incident_number)
        if pipelineIncident is None:
            print("Pipeline incident not found")
        else:
            print(pipelineIncident.to_csv_format())

    def create_record(self):
        """Allows users to create new records"""
        incident_number = input("Enter incident number: ")
        incident_types = input("Enter incident types: ")
        reported_date = input("Enter reported date: ")
        nearest_populated_centre = input("Enter nearest populated centre: ")
        province = input("Enter province: ")
        company = input("Enter compnay: ")
        substance = input("Enter substance: ")
        significant = input("Enter significant: ")
        what_happened_category = input("Enter what happened category: ")

        self.__businessLayer.create_record(incident_number, incident_types, reported_date, nearest_populated_centre, province, company, substance, significant, what_happened_category)
        print("Pipeline incident record created!")

    def edit_record(self):
        """Allows users to edit existing records"""
        incident_number = input("Enter incident number: ")
        incident_types = input("Enter incident types: ")
        reported_date = input("Enter reported date: ")
        nearest_populated_centre = input("Enter nearest populated centre: ")
        province = input("Enter province: ")
        company = input("Enter company: ")
        significant = input("Enter significant: ")
        substance = input("Enter substance: ")
        what_happened_category = input("Enter what happened category: ")

        result = self.__businessLayer.edit_record(incident_number, incident_types, reported_date, nearest_populated_centre, province,
                                                  company, substance, significant, what_happened_category)

        if result:
            print("Pipeline incident record edited!")
        else:
            print("Pipeline incident record not found!")

    def delete_record(self):
        """Allows users to delete existing records"""
        incident_number = input("Enter incident number: ")
        result = self.__businessLayer.delete_record(incident_number)

        if result:
            print("Pipeline incident record deleted!")
        else:
            print("Pipeline incident record not found!")

    def get_user_input(self, prompt):
        """Gets input from the user"""
        return input(prompt)

    def display_menu(self):
        """Displays the menu to the user"""
        print("............ Taranjeet Kaur...........................")
        print("1. Reload the data from the dataset")
        print("2. Persist the data from memory to the disk as a comma-separated file")
        print("3. Select and display a record")
        print("4. Create a new record")
        print("5. Select and edit a record")
        print("6. Select and delete a record")
        print("7. Quit")


def main():
    app = PresentationLayer()

    selected_option = 1

    while selected_option != 7:
        app.display_menu()
        selected_option = int(app.get_user_input("> "))

        if selected_option == 1:
            app.reload_dataset()
        elif selected_option == 2:
            app.persist_data()
        elif selected_option == 3:
            app.select_record()
        elif selected_option == 4:
            app.create_record()
        elif selected_option == 5:
            app.edit_record()
        elif selected_option == 6:
            app.delete_record()
        elif selected_option != 7:
            print("Wrong selection!")
        print("\n\n")


if __name__ == "__main__":
    main()







