package assign3;

public class Main {

    public static void main(String[] args) {
        System.out.println("Array Queue:");
        new Main(new ArrayDoubleEndedQueue<>());
        System.out.println();
        System.out.println();
        System.out.println("Linked Queue:");
        new Main(new LinkedDoubleEndedQueue<>());
    }

    private Main(final DoubleEndedQueue<String> queue) {
        String el;
        for (String s: new String[] {"A", "B", "C"}) {
            queue.offerRear(s);
        }
        print("Offer Rear: A, B, C", queue);
        queue.offerRear("D");
        print("Offer Rear: D", queue);
        System.out.println();

        queue.offerFront("E");
        print("Offer Front: E", queue);
        el = queue.pollRear();
        print("Poll Rear: - returns " + el, queue);
        System.out.println();

        el = queue.pollFront();
        print("Poll Front: - returns " + el, queue);
        el = queue.front();
        print("Front: - returns " + el, queue);
        System.out.println();

        el = queue.rear();
        print("Rear: - returns " + el, queue);
        el = queue.pollRear();
        print("Poll Rear: - returns " + el, queue);
    }

    private void print(String label, DoubleEndedQueue<String> queue) {
        System.out.printf("%-30s %-30s", label, "Queue: " + queue);
    }
}
