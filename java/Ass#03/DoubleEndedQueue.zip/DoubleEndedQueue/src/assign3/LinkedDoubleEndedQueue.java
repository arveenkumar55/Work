package assign3;

import java.util.Iterator;

public class LinkedDoubleEndedQueue<E> implements DoubleEndedQueue<E> {
    private Node<E> front;
    private Node<E> rear;
    private int size;

    @Override
    public void offerFront(E element) {
        if (front == null && rear == null) {
            front = rear = new Node<>(element, null, null);
        } else {
            front = new Node<>(element, front, null);
        }

        size++;
    }

    @Override
    public void offerRear(E element) {
        if (front == null && rear == null) {
            front = rear = new Node<>(element, null, null);
        } else {
            Node<E> node = new Node<>(element, null, rear);
            rear.next = node;
            rear = node;
        }

        size++;
    }

    @Override
    public E pollFront() {
        Node<E> node = front;
        front = front.next;
        front.previous = null;
        size--;
        return node.data;
    }

    @Override
    public E pollRear() {
        Node<E> node = rear;
        rear = rear.previous;
        rear.next = null;
        size++;
        return node.data;
    }

    @Override
    public E front() {
        return front.data;
    }

    @Override
    public E rear() {
        return rear.data;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public int clear() {
        front = rear = null;
        size = 0;
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private Node<E> node = front;

            @Override
            public boolean hasNext() {
                return node != null;
            }

            @Override
            public E next() {
                Node<E> n = node;
                node = node.next;
                return n.data;
            }
        };
    }

    private static class Node<E> {
        E data;
        Node<E> next;
        Node<E> previous;

        public Node(E data, Node<E> next, Node<E> previous) {
            this.data = data;
            this.next = next;
            this.previous = previous;
        }
    }

    @Override
    public String toString() {
        if (isEmpty()) return "[]";

        final StringBuilder builder = new StringBuilder("[");
        iterator().forEachRemaining(it -> builder.append(it).append(", "));
        return builder.replace(builder.lastIndexOf(", "), builder.length(), "").append("]").toString();
    }
}
