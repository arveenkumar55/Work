package assign3;

import javax.naming.SizeLimitExceededException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArrayDoubleEndedQueue<E> implements DoubleEndedQueue<E> {

    private E[] arr;
    private int front;
    private int rear;
    private int size;

    public ArrayDoubleEndedQueue() {
        arr = (E[]) new Object[16];
    }

    @Override
    public void offerFront(E element) {
        if (size == arr.length) throw new RuntimeException("Size of queue has exceeded");
        arr[front = (front - 1) & (arr.length - 1)] = element;
        size++;
    }

    @Override
    public void offerRear(E element) {
        arr[rear] = element;
        rear = (rear + 1) & (arr.length - 1);
    }

    @Override
    public E pollFront() {
        int f = front;
        E result = arr[f];
        if (result == null)
            throw new NoSuchElementException();

        arr[f] = null;
        front = (f + 1) & (arr.length - 1);
        return result;
    }

    @Override
    public E pollRear() {
        int r = (rear - 1) & (arr.length - 1);
        E result = arr[r];
        if (result == null)
            throw new NoSuchElementException();

        arr[r] = null;
        rear = r;
        return result;
    }

    @Override
    public E front() {
        E result = arr[front];
        if (result == null)
            throw new NoSuchElementException();

        return result;
    }

    @Override
    public E rear() {
        E result = arr[rear - 1];
        if (result == null)
            throw new NoSuchElementException();

        return result;
    }

    @Override
    public int size() {
        return (rear - front) & (arr.length - 1);
    }

    @Override
    public int clear() {
        front = 0;
        rear = 0;
        arr = (E[]) new Object[arr.length];
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return front == rear;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private int cursor = front;
            @Override
            public boolean hasNext() {
                return cursor != rear;
            }

            @Override
            public E next() {
                E result = arr[cursor];
                cursor = (cursor + 1) & (arr.length - 1);
                return result;
            }
        };
    }

    @Override
    public String toString() {
        if (isEmpty()) return "[]";

        final StringBuilder builder = new StringBuilder("[");
        iterator().forEachRemaining(it -> builder.append(it).append(", "));
        return builder.replace(builder.lastIndexOf(", "), builder.length(), "").append("]").toString();
    }
}
