package assign3;

import java.util.Iterator;

public interface DoubleEndedQueue<E> {
    void offerFront(E element);

    void offerRear(E element);

    E pollFront();

    E pollRear();

    E front();

    E rear();

    int size();

    int clear();

    boolean isEmpty();

    Iterator<E> iterator();
}
