import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class PancakeCanvasPanel extends JPanel implements MouseListener {

    private PancakeStack stack;
    private Consumer<Pancake> onClickListener;
    private Map<Rectangle, Pancake> pancakeIndex;

    public PancakeCanvasPanel(PancakeStack stack) {
        this.stack = stack;
        addMouseListener(this);
    }

    public PancakeCanvasPanel(PancakeStack stack, Consumer<Pancake> onClickListener) {
        this.stack = stack;
        this.onClickListener = onClickListener;
        addMouseListener(this);
    }

    public PancakeStack getStack() {
        return stack;
    }

    public void setOnClickListener(Consumer<Pancake> onClickListener) {
        this.onClickListener = onClickListener;
    }

    void setStack(PancakeStack stack) {
        this.stack = stack;
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(1000, 600);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        pancakeIndex = new HashMap<>();
        for (int i = 0; i < stack.size(); i++) {
            Pancake pancake = stack.get(i);
            pancakeIndex.put(pancake.draw(g, 100 + i * 20), pancake);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (onClickListener == null) return;

        for (Rectangle rectangle : pancakeIndex.keySet()) {
            if (rectangle.contains(e.getPoint())) onClickListener.accept(pancakeIndex.get(rectangle));
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
