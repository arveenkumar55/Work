import javax.swing.*;
import java.awt.*;

public class Components {
    public static JButton createButton(Container container, String text, Runnable onClick) {
        JButton button = new JButton();
        button.setText(text);
        button.addActionListener(l -> onClick.run());

        container.add(button);
        return button;
    }
}
