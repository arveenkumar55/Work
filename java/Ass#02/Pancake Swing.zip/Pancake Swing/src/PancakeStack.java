import java.util.*;
import java.util.function.Consumer;

public class PancakeStack extends ArrayList<Pancake> {

    public static PancakeStack stackOf(Pancake ...args) {
        PancakeStack stack = new PancakeStack();
        stack.addAll(Arrays.asList(args));
        return stack;
    }

    public PancakeStack() {
    }

    public PancakeStack(Collection<? extends Pancake> c) {
        super(c);
    }

    void push(Pancake pancake) {
        add(pancake);
    }

    Pancake pop() {
        Pancake cake = get(size() - 1);
        remove(size() - 1);
        return cake;
    }

    Pancake peek() {
        return get(size() - 1);
    }

    int findMax(int offset) {
         if (subList(0, offset).isEmpty()) return 0;

        return subList(0, offset)
                .stream()
                .max(Pancake::compareTo)
                .map(this::indexOf)
                .orElseThrow(NullPointerException::new);
    }

    void flip(int offset) {
        int left = 0;
        while (left < offset) {
            Pancake tmp = get(left);
            set(left, get(offset));
            set(offset, tmp);
            offset--; left++;
        }
    }

    public void sort() {
        sort(it -> {});
    }

    public void sort(Consumer<PancakeStack> onChangeListener) {
        final PancakeSort sort = new PancakeSort(this, onChangeListener);
        while (sort.sort());
    }

}
