import java.awt.*;
import java.util.Objects;

public class Pancake implements Comparable<Pancake> {
    private Color color;
    private int size;
    private boolean selected;

    private static final int BORDER_SIZE = 2;

    public Pancake(int size, Color color) {
        this.color = color;
        this.size = size;
    }

    void highlight(boolean selected) {
        this.selected = selected;
    }

    public int getSize() {
        return size;
    }

    Rectangle draw(Graphics g, int y) {
        int x = size / 2;
        final Rectangle rect = new Rectangle(500 - x, y, x * 2, 20);
        if (selected) {
            g.setColor(Color.BLACK);
            g.fillRoundRect(500 - x - BORDER_SIZE, y - BORDER_SIZE,  (BORDER_SIZE + x) * 2, 20 + BORDER_SIZE * 2, 8, 8);
        }

        g.setColor(color);
        g.fillRoundRect(500 - x, y, x * 2, 20, 8, 8);

        g.setColor(Color.WHITE);
        drawCenteredString(g, String.valueOf(size), rect, Font.decode("Arial"));

        return rect;
    }

    public void drawCenteredString(Graphics g, String text, Rectangle rect, Font font) {
        // Get the FontMetrics
        FontMetrics metrics = g.getFontMetrics(font);
        // Determine the X coordinate for the text
        int x = rect.x + (rect.width - metrics.stringWidth(text)) / 2;
        // Determine the Y coordinate for the text (note we add the ascent, as in java 2d 0 is top of the screen)
        int y = rect.y + ((rect.height - metrics.getHeight()) / 2) + metrics.getAscent();
        // Set the font
        g.setFont(font);
        // Draw the String
        g.drawString(text, x, y);
    }

    @Override
    public int compareTo(Pancake o) {
        return Integer.compare(size, o.size);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pancake pancake = (Pancake) o;
        return size == pancake.size && selected == pancake.selected && Objects.equals(color, pancake.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(color, size, selected);
    }

    @Override
    public String toString() {
        return String.format("Pancake{color=%s, size=%d, selected=%s}", color, size, selected);
    }
}
