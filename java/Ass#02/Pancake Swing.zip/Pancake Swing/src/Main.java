import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;

public class Main {

    private static final Color[] COLORS = new Color[]{
            Color.LIGHT_GRAY,
            Color.GRAY,
            Color.DARK_GRAY,
            Color.BLACK,
            Color.RED,
            Color.PINK,
            Color.ORANGE,
            Color.YELLOW,
            Color.GREEN,
            Color.MAGENTA,
            Color.CYAN,
            Color.BLUE
    };
    private static final Random RANDOM = new Random();
    private final PancakeStack stack = new PancakeStack();

    private JFrame root;

    Main() {
        generateData();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().start());
    }

    private void start() {
        root = new JFrame("Pancake sort problem");
        root.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        root.setSize(1000, 600);

        root.setLayout(new BorderLayout());

        PancakeCanvasPanel canvas = new PancakeCanvasPanel(new PancakeStack(stack));

        canvas.setOnClickListener(it -> {
            canvas.getStack().flip(canvas.getStack().indexOf(it));
            root.repaint();
        });
        root.add(canvas, BorderLayout.CENTER);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        Components.createButton(panel, "Reset", () -> {
            canvas.setStack(new PancakeStack(this.stack));
            root.repaint();
        });
        Components.createButton(panel, "Resolve", () -> {
            animateSorting(root, canvas.getStack());
        });
        root.add(panel, BorderLayout.SOUTH);

        root.pack();
        root.setVisible(true);
    }

    private static void animateSorting(Container root, PancakeStack stack) {
        new Thread(() -> stack.sort(it -> {
            try {
                Thread.sleep(100);
                root.repaint();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        })).start();
    }

    private void generateData() {
        for (int i = 0; i < 12; i++) {
            stack.push(new Pancake(RANDOM.nextInt(200) + 50, COLORS[i]));
        }
    }

}
