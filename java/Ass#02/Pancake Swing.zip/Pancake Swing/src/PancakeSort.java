import java.util.function.Consumer;

public class PancakeSort {

    private final PancakeStack stack;
    private final Consumer<PancakeStack> onChangeListener;
    private int n;

    public PancakeSort(PancakeStack stack) {
        this(stack, (it) -> {});
    }

    public PancakeSort(PancakeStack stack, Consumer<PancakeStack> onChangeListener) {
        this.stack = stack;
        this.onChangeListener = onChangeListener;
        this.n = stack.size();
    }

    public boolean sort() {
        if (n > 1) {
            stack.get(n - 1).highlight(true);
            int maxIndex = stack.findMax(n);
            stack.flip(maxIndex);
            onChangeListener.accept(stack);
            stack.flip(n - 1);
            onChangeListener.accept(stack);
            n--;
            return true;
        }

        return false;
    }

}
