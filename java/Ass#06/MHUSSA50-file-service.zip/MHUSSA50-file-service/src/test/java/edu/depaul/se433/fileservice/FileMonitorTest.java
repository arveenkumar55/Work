/*
 * Assignment #8
 * Topic: Mocks
 * Author: <YOUR NAME>
 */

package edu.depaul.se433.fileservice;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class FileMonitorTest {

    @Test
    @DisplayName("Check if the FileMonitor doesn't throw any exception if FileService returns empty list")
    public void testIfExceptionIsThrow() {
        FileService service = mock(FileService.class);
        when(service.getDirectoryContents(any())).thenReturn(new ArrayList<>());

        FileMonitor monitor = new FileMonitor(service);
        assertDoesNotThrow(() -> {
            monitor.clean("/");
        });
    }

    @Test
    @DisplayName("Check if the FileMonitor returned the names of files that are removed")
    public void testIfSubListIsReturned() {
        FileService service = mock(FileService.class);
        when(service.getDirectoryContents(any())).thenReturn(List.of("a.tmp", "b.tmp", "c.txt"));

        FileMonitor monitor = new FileMonitor(service);
        assertEquals(monitor.clean("/"), List.of("a.tmp", "b.tmp"));
    }

    @Test
    @DisplayName("Check if the FileMonitor doesn't invoked delete calls if there are no tmp files")
    public void testIfDeleteCallsAreNotInvoked() {
        FileService service = mock(FileService.class);
        when(service.getDirectoryContents(any())).thenReturn(List.of("b.txt", "c.txt"));

        FileMonitor monitor = new FileMonitor(service);
        monitor.clean("/");
        verify(service, times(0)).delete("delete was not called");
    }

}
