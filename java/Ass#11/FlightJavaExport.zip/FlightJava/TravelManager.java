package hw2;

import hw2.exception.BadParameterException;
import hw2.exception.NullParameterException;
import hw2.flight.Flight;

import java.util.Optional;

public class TravelManager {

    public static void main(String[] args) throws Exception {
        try {
            FlightManager manager = new FlightManagerProxy();
            String flightNumber = manager.createFlight("passengerFlight", "Spirit", "ORD", "DFW", 0);
            Optional<Flight> flight = manager.getFlightByFlightNumber(flightNumber);

            System.out.println(flight.get());
        } catch (NullParameterException | BadParameterException ex) {
            ex.printStackTrace();
        }
    }

}
