package hw2;

import hw2.airline.AirlineFactory;
import hw2.airport.AirportFactory;
import hw2.exception.BadParameterException;
import hw2.exception.NullParameterException;
import hw2.flight.Flight;
import hw2.flight.FlightFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class FlightManagerImpl implements FlightManager {

    private static FlightManagerImpl ourInstance;
    private final List<Flight> flights;

    private final AirlineFactory airlineFactory = AirlineFactory.getInstance();
    private final AirportFactory airportFactory = AirportFactory.getInstance();

    private FlightManagerImpl() {
        flights = new ArrayList<Flight>();
    }

    public static FlightManagerImpl getInstance() {
        if (ourInstance == null)
            ourInstance = new FlightManagerImpl();

        return ourInstance;
    }

    @Override
    public String createFlight(String type, String airline, String origin, String destination, int capacity) throws BadParameterException, NullParameterException {
        Flight flight = FlightFactory.createFlight(
                type,
                airlineFactory.getAirline(airline),
                airportFactory.getAirport(origin),
                airportFactory.getAirport(destination),
                capacity
        );

        if (flight == null)
            throw new NullParameterException("Flight is null");

        flights.add(flight);
        return flight.getFlightNumber();
    }

    @Override
    public Optional<Flight> getFlightByFlightNumber(String flightNumber) {
        return flights.stream()
                .filter(flt -> flt.getFlightNumber().equals(flightNumber))
                .findFirst();
    }
}