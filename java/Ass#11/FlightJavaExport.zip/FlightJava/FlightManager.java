package hw2;

import hw2.exception.BadParameterException;
import hw2.exception.NullParameterException;
import hw2.flight.Flight;

import java.util.Optional;

public interface FlightManager {

    String createFlight(
            String type,
            String airline,
            String origin,
            String destination,
            int capacity
    ) throws BadParameterException, NullParameterException;

    Optional<Flight> getFlightByFlightNumber(String flightNumber);

}
