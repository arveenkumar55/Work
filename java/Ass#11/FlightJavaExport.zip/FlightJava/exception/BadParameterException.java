package hw2.exception;

public class BadParameterException extends Throwable {
    public BadParameterException(String s) {
        super(s);
    }
}
