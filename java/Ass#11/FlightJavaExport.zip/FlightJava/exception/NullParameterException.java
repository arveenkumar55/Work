package hw2.exception;

public class NullParameterException extends Throwable {
    public NullParameterException(String s) {
        super(s);
    }
}
