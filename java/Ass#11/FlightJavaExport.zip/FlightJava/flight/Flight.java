package hw2.flight;

public interface Flight {
    String getFlightNumber();
}
