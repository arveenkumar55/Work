package examproject;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class Main {
    private static final String DATABASE_URL = "jdbc:derby://localhost:1527/employee";
    private static final String SELECT_QUERY = "SELECT USERNAME, PASSWORD FROM \"user\"";

    private static Map<String, String> userAuth = new HashMap<>();

    public static void main(String[] args) {
        configureAuth();
        new LoginFrame(userAuth);
    }

    private static void configureAuth() {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(SELECT_QUERY);

            while (resultSet.next()) userAuth.put(resultSet.getString(1), resultSet.getString(2));
        } catch (SQLException sqlException) {
            System.err.println(sqlException.getMessage());
        }
    }
}

class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginFrame(Map<String, String> userAuth) {
        setSize(300, 200);
        setVisible(true);
        setName("Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        setAlignment(panel);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        add(panel);

        usernameField = new JTextField(10);
        usernameField.setMaximumSize(new Dimension(200, 20));
        setAlignment(usernameField);

        passwordField = new JPasswordField(10);
        passwordField.setMaximumSize(new Dimension(200, 20));
        setAlignment(passwordField);

        loginButton = new JButton("Login");
        setAlignment(loginButton);
        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());


            if (userAuth.containsKey(username) && userAuth.get(username).equals(password)) {
                JOptionPane.showMessageDialog(null, "Login Successful");
            } else if (username.isEmpty() && password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Username and Password cannot be empty");
            } else {
                JOptionPane.showMessageDialog(null, "Login Failed");
            }
        });

        JLabel usernameLabel = new JLabel("Username");
        setAlignment(usernameLabel);
        panel.add(usernameLabel);
        panel.add(usernameField);
        JLabel passwordLabel = new JLabel("Password");
        setAlignment(passwordLabel);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);

        pack();
    }

    private void setAlignment(JComponent component) {
        component.setAlignmentX(Component.CENTER_ALIGNMENT);
        component.setAlignmentY(Component.CENTER_ALIGNMENT);
    }
}