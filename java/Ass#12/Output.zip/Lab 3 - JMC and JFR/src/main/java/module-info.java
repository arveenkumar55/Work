open module com.algonquincollege.cst8277.labexercise3 {
	requires java.base;
}