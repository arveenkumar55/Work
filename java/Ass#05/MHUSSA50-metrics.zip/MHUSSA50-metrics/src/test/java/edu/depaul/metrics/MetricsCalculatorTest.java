package edu.depaul.metrics;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MetricsCalculatorTest {

  // the number of minutes in 1 week
  private static final int ONE_WEEK = 10080;

  @Test
  @DisplayName("MTBF should be 3331.67 for given events")
  void mtbf_test1() {
    int[] events = {75, 3, 7};

    MetricsCalculator calculator = new MetricsCalculator();

    double mtbf = calculator.getMTBF(events, ONE_WEEK);
    assertEquals(3331.67, mtbf, 1e-2);
  }

  @Test
  @DisplayName("MTBF should be 2014 for the given events")
  void mtbf_test2() {
    int[] events = {2,2,2,2,2};   // 1 ten minute event

    MetricsCalculator calculator = new MetricsCalculator();

    double mtbf = calculator.getMTBF(events, ONE_WEEK);
    assertEquals(2014.0, mtbf, 1e-2);
  }


  @Test
  @DisplayName("Illegal argument exception should be thrown when empty events are passed to MTBF")
  void mtbf_test3() {
    int[] events = {};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getMTBF(events, ONE_WEEK));
    assertEquals("Events array is null or empty", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when null events are passed to MTBF")
  void mtbf_test4() {
    int[] events = {};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getMTBF(events, ONE_WEEK));
    assertEquals("Events array is null or empty", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative scope is passed to MTBF")
  void mtbf_test5() {
    int[] events = {75, 3, 7};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getMTBF(events, -1));
    assertEquals("Scope can not be less than equal to zero", exception.getMessage());
  }

  @Test
  @DisplayName("MTTR should be 28.33 for the given events")
  void mttr_test1() {
    int[] events = {75, 3, 7};

    MetricsCalculator calculator = new MetricsCalculator();

    double mttr = calculator.getMTTR(events, ONE_WEEK);
    assertEquals(28.33, mttr, 1e-2);
  }

  @Test
  @DisplayName("MTTR should be 2 for the given events")
  void mttr_test2() {
    int[] events = {2,2,2,2,2};

    MetricsCalculator calculator = new MetricsCalculator();

    double mtbf = calculator.getMTTR(events, ONE_WEEK);
    assertEquals(2.0, mtbf, 1e-2);
  }


  @Test
  @DisplayName("Illegal argument exception should be thrown when empty events are passed to MTTR")
  void mttr_test3() {
    int[] events = {};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getMTTR(events, ONE_WEEK));
    assertEquals("Events array is null or empty", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when null events are passed to MTTR")
  void mttr_test4() {
    int[] events = {};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getMTTR(events, ONE_WEEK));
    assertEquals("Events array is null or empty", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative scope is passed to MTTR")
  void mttr_test5() {
    int[] events = {75, 3, 7};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getMTTR(events, -1));
    assertEquals("Scope can not be less than equal to zero", exception.getMessage());
  }

  @Test
  @DisplayName("Downtimes of 75,3, and 7 should result is availability of 99.15%")
  void availability_test1() {
    int[] events = {75, 3, 7};

    MetricsCalculator calculator = new MetricsCalculator();

    double availability = calculator.getAvailability(events, ONE_WEEK);
    assertEquals(99.15, availability, 1e-2);
  }

  @Test
  @DisplayName("5 Downtimes of 2 should result is availability of 99.9%")
  void availability_test2() {
    int[] events = {2,2,2,2,2};

    MetricsCalculator calculator = new MetricsCalculator();

    double availability = calculator.getAvailability(events, ONE_WEEK);
    assertEquals(99.9, availability, 1e-2);
  }


  @Test
  @DisplayName("Illegal argument exception should be thrown when empty events are passed to getAvailability")
  void availability_test3() {
    int[] events = {};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getAvailability(events, ONE_WEEK));
    assertEquals("Events array is null or empty", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when null events are passed to getAvailability")
  void availability_test4() {
    int[] events = {};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getAvailability(events, ONE_WEEK));
    assertEquals("Events array is null or empty", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative scope is passed to getAvailability")
  void availability_test5() {
    int[] events = {75, 3, 7};

    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getAvailability(events, -1));
    assertEquals("Scope can not be less than equal to zero", exception.getMessage());
  }

  @Test
  @DisplayName("When sessions per hour is 12 and session length is 15 an downtime is 30, affected users is 9")
  void affected_users_is_9() {

    MetricsCalculator calculator = new MetricsCalculator();

    double users = calculator.getAffectedUsers(12, 15, 30);
    assertEquals(9.0, users, 1e-4);
  }

  @Test
  @DisplayName("When sessions per hour is 60 and session length is 15 an downtime is 60, affected users is 75")
  void affected_users_is_75() {
    MetricsCalculator calculator = new MetricsCalculator();

    double users = calculator.getAffectedUsers(60, 15, 60);
    assertEquals(75.0, users, 1e-4);
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative session per hour is passed to getReliability")
  void getAffectedUsers3() {
    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getAffectedUsers(-1, 15, 30));
    assertEquals("Session per hour can not be less than equal to zero", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative session length is passed to getAffectedUsers")
  void getAffectedUsers4() {
    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getAffectedUsers(12, -1, 30));
    assertEquals("Session length can not be less than equal to zero", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative down time is passed to getAffectedUsers")
  void getAffectedUsers5() {
    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getAffectedUsers(12, 15, -1));
    assertEquals("Down time can not be less than zero", exception.getMessage());
  }

  @Test
  @DisplayName("when affected users is 75, reliability is 94.791")
  void getReliability1() {
    MetricsCalculator calculator = new MetricsCalculator();

    double rel = calculator.getReliability(60, 15, 60, 24);
    assertEquals(94.791, rel, 1e-3);
  }

  @Test
  @DisplayName("when affected users is 9, reliability is 94.791")
  void getReliability2() {
    MetricsCalculator calculator = new MetricsCalculator();

    double rel = calculator.getReliability(12, 15, 30, 24);
    assertEquals(96.875, rel, 1e-3);
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative session per hour is passed to getReliability")
  void getReliability3() {
    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getReliability(-1, 15, 30, 24));
    assertEquals("Session per hour can not be less than equal to zero", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative session length is passed to getReliability")
  void getReliability4() {
    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getReliability(12, -1, 30, 24));
    assertEquals("Session length can not be less than equal to zero", exception.getMessage());
  }

  @Test
  @DisplayName("Illegal argument exception should be thrown when negative down time is passed to getReliability")
  void getReliability5() {
    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getReliability(12, 15, -1, 24));
    assertEquals("Down time can not be less than zero", exception.getMessage());
  }
  
  @Test
  @DisplayName("Illegal argument exception should be thrown when negative scope is passed to getReliability")
  void getReliability6() {
    MetricsCalculator calculator = new MetricsCalculator();

    final var exception = assertThrows(IllegalArgumentException.class, () -> calculator.getReliability(12, 15, 30, -1));
    assertEquals("Scope can not be less than equal to zero", exception.getMessage());
  }

}
