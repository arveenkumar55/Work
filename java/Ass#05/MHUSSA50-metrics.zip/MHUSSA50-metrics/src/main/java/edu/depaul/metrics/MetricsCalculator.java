package edu.depaul.metrics;

import java.util.Arrays;

/**
 * Provides calculations for:
 * MTBF
 * MTTR
 * Availability
 * Affected users
 * Reliability
 */
public class MetricsCalculator {
  public MetricsCalculator() {}

  /**
   * Calculate Mean Time Between Failures
   * @param events an array of downtime durations example: {7, 3}
   *               represents two events that took 7 and 3 minutes
   * @param scope the duration of the total time being considered.
   *              for example, scope of 10080 would be 1 week in minutes
   * @return the calculated MTBF for the given events and scope
   */
  public double getMTBF(int[] events, int scope) {
    if (events == null || events.length == 0) throw new IllegalArgumentException("Events array is null or empty");
    if (scope <= 0) throw new IllegalArgumentException("Scope can not be less than equal to zero");

    return (double) (scope - Arrays.stream(events).sum()) / events.length;
  }

  /**
   * Identical inputs the getMTBF() above
   * @return the calculated MTTR
   */
  public double getMTTR(int[] events, int scope) {
    if (events == null || events.length == 0) throw new IllegalArgumentException("Events array is null or empty");
    if (scope <= 0) throw new IllegalArgumentException("Scope can not be less than equal to zero");

    return (double) Arrays.stream(events).sum() / events.length;
  }

  /**
   * Identical inputs the getMTBF() above
   * @return the calculated availability
   */
  public double getAvailability(int[] events, int scope) {
    if (events == null || events.length == 0) throw new IllegalArgumentException("Events array is null or empty");
    if (scope <= 0) throw new IllegalArgumentException("Scope can not be less than equal to zero");

    return ((double) (scope - Arrays.stream(events).sum()) / scope) * 100;
  }

  /**
   * Calculate the predicted number of affected users, given the session
   * information provided.
   * @param sessionsPerHour in general, the number of sessions per hour
   * @param sessionLength the average duration, in minutes of a single session
   * @param downTime the number of minutes the system was down
   * @return total number of user affected.  Includes dropped sessions as well
   * as # of users unable to connect during the downtime
   */
  public double getAffectedUsers(int sessionsPerHour, int sessionLength, double downTime) {
    if (sessionsPerHour <= 0) throw new IllegalArgumentException("Session per hour can not be less than equal to zero");
    if (sessionLength <= 0) throw new IllegalArgumentException("Session length can not be less than equal to zero");
    if (downTime < 0) throw new IllegalArgumentException("Down time can not be less than zero");

    final var totalSessions = sessionsPerHour * 24;
    final var averageLiveUsers =  ((double) sessionsPerHour / 60) * sessionLength;
    final var successfulSessions = sessionsPerHour * (24 - (downTime / 60)) - averageLiveUsers;
    return totalSessions - successfulSessions;
  }

  /**
   * Calculates the reliability of a system over a give period of time (scope)
   * The first 3 parameters are identical to those given in getAffectedUsers
   * @param scope the total amount of time for the calculation, given in hours
   * @return
   */
  public double getReliability(int sessionsPerHour, int sessionLength, double downTime, int scope) {
    if (sessionsPerHour <= 0) throw new IllegalArgumentException("Session per hour can not be less than equal to zero");
    if (sessionLength <= 0) throw new IllegalArgumentException("Session length can not be less than equal to zero");
    if (downTime < 0) throw new IllegalArgumentException("Down time can not be less than zero");
    if (scope <= 0) throw new IllegalArgumentException("Scope can not be less than equal to zero");

    final var totalSessions = sessionsPerHour * 24;
    final var averageLiveUsers =  ((double) sessionsPerHour / 60) * sessionLength;
    final var successfulSessions = sessionsPerHour * (24 - (downTime / 60)) - averageLiveUsers;
    return (successfulSessions / totalSessions) * 100;
  }
}
