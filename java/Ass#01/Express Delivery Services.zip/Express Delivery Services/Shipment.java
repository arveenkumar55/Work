/**
 * Write a description of class Shipment here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Shipment {
    private int id;
    private double total_shipping_cost, amount_payable, voucher_amount;
    private String shipment_status;

    public Shipment(int id, double total_shipping_cost, double amount_payable, double voucher_amount) {
        this.id = id;
        this.total_shipping_cost = total_shipping_cost;
        this.amount_payable = amount_payable;
        this.voucher_amount = voucher_amount;
        this.shipment_status = "W";
    }

    public void setShipment_status(String shipment_status) {
        this.shipment_status = shipment_status;
    }

    public int getId() {
        return id;
    }

    public String getShipment_status() {
        return shipment_status;
    }

    public String toString() {
        return "Shipment ID: "+id
                +"\nTotal Shipping Cost: "+total_shipping_cost
                +"\nVoucher Amount: "+voucher_amount
                +"\nTotal Amount Payable: "+amount_payable
                +"\nShipment Status: "+shipment_status;
    }
    
}
