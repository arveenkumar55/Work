import javax.swing.JOptionPane;

public class main {

    private final static int ADD = 1;
    private final static int UPDATE = 2;
    private final static int DISPLAY = 3;
    private final static int EXIT = 4;

    static int studentID = 20526681;

    static double weight;
    static double distance;
    static int code;
    static double discount = 0;
    static double rate = 0;
    static double total = 0;
    static double payable = 0;
    static int id;
    static String str;
    static int flag = 0;
    static int i = 0;
    static String status;
    static Shipment shipments[] = new Shipment[50];
    static Voucher vouchers[] = new Voucher[5];
    static int len = 0;

    public static void run() {
        vouchers[0] = new Voucher(1111, 10);
        vouchers[1] = new Voucher(2222, 20);
        vouchers[2] = new Voucher(3333, 30);
        vouchers[3] = new Voucher(4444, 40);
        vouchers[4] = new Voucher(5555, 50);
        int choice = -1;
        while (choice != EXIT) {
//            displayMenu();
            choice = Integer.parseInt(JOptionPane.showInputDialog(null, "Welcome to Express Delivery. You can select an option from 1 - 4."
                    + "\n\t" + ADD + ". Add Shipping Order "
                    + "\n\t" + UPDATE + ". Update Shipping Status"
                    + "\n\t" + DISPLAY + ". Display all Orders"
                    + "\n\t" + EXIT + ". Exit the System"
                    + "\nEnter choice >> ",
                     "Main Window", JOptionPane.QUESTION_MESSAGE));
            process(choice);
        }
    }
    
    static void process(int choice) {
        switch (choice) {
            case ADD:
                add();
                break;

            case UPDATE:
                update();
                break;

            case DISPLAY:
                display();
                break;

            case EXIT:
                JOptionPane.showMessageDialog(null, "Thank you for using Shipping Express Company!", "Exit", JOptionPane.INFORMATION_MESSAGE);
                break;

            default:
                JOptionPane.showMessageDialog(null, choice + " is not a valid choice!", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }

    public static void add() {
        if (len < 50) {
            weight = Double.parseDouble(JOptionPane.showInputDialog("Enter weight of the parcel:"));
            while (weight < 1 || weight > 30) {
                JOptionPane.showMessageDialog(null, "Weight should lie between 1 to 30 kg.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                weight = Double.parseDouble(JOptionPane.showInputDialog("Enter weight of the parcel:"));
            }
            distance = Double.parseDouble(JOptionPane.showInputDialog("Enter distance of the destination:"));
            while (distance < 5 || distance > 3000) {
                JOptionPane.showMessageDialog(null, "Distance should lie between 5 to 3000 km.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                distance = Double.parseDouble(JOptionPane.showInputDialog("Enter distance of the destination:"));
            }
            code = Integer.parseInt(JOptionPane.showInputDialog("Enter Voucher Code:"));
            int count = 0;
            for (Voucher voucher : vouchers) {
                if (code == voucher.id) {
                    discount = voucher.value;
                    break;
                } else {
                    count++;
                }
                if (count == 5) {
                    JOptionPane.showMessageDialog(null, "Voucher does not exist.\nNo voucher applied!", "Invalid Voucher Number", JOptionPane.ERROR_MESSAGE);
                    discount = 0;
                }
            }
            if (weight <= 2) {
                rate = 8.10;
            } else if (weight <= 6) {
                rate = 9.20;
            } else if (weight <= 10) {
                rate = 12.70;
            } else {
                rate = 16.80;
            }
            total = rate * distance;
            if (total <= discount) {
                payable = 0;
            } else {
                payable = total - discount;
            }
            shipments[len++] = new Shipment(studentID++, total, payable, discount);
            JOptionPane.showMessageDialog(null, shipments[len - 1].toString(), "Shipment Details", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Memory is full, no free space", "Memory full", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void update() {
        str = "All the shipment IDs are:\n";
        for (i = 0; i < len; i++) {
            if (shipments[i].getShipment_status().equals("P") || shipments[i].getShipment_status().equals("W")) {
                str = str+shipments[i].getId()+"\n";
            }
        }
        id = Integer.parseInt(JOptionPane.showInputDialog(str+"Enter Shipment ID:"));
        for (i = 0; i < len; i++) {
            if (id == shipments[i].getId()) {
                if (shipments[i].getShipment_status().equals("P") || shipments[i].getShipment_status().equals("W")) {
                    status = JOptionPane.showInputDialog("Enter status (P or D):").toUpperCase();
                    if (status.equals("P") || status.equals("D")) {
                        shipments[i].setShipment_status(status);
                    } else {
                        JOptionPane.showMessageDialog(null, "Status should be 'D' or 'P'!", "Invalid Status", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Shipment Status cannot be changed!", "Invalid Shipment ID", JOptionPane.ERROR_MESSAGE);
                }
                flag = 1;
                break;
            }
        }
        if (i == len && flag == 0) {
            JOptionPane.showMessageDialog(null, "Shipment id not found!", "Invalid Shipment ID", JOptionPane.ERROR_MESSAGE);
        }
        flag = 0;
    }

    public static void display() {
        System.out.println("Displaying all Orders:\n");
        for (i = 0; i < len; i++) {
            System.out.println(shipments[i].toString() + "\n");
        }
    }
}