public class Voucher {
    int id;
    double value;

    public Voucher(int id, double value) {
        this.id = id;
        this.value = value;
    }
    
}
