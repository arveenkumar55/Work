public interface Level {
    boolean isDebug = false;

    String getName();

    String getTitle();

    String getDescription();

    void play(boolean isSecondChance) throws LevelFailureException;
}
