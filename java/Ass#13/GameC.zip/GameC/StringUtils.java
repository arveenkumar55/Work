import java.util.*;

public class StringUtils {

    private StringUtils() {}

    @SuppressWarnings("DuplicatedCode")
    // While the code seems duplicate, it is due to primitive types arrays
    public static String joinToString(char[] word) {
        return joinToString(word, " ");
    }

    private static String joinToString(char[] word, String joining) {
        StringBuilder sb = new StringBuilder();
        for (char c : word) {
            sb.append(c).append(joining);
        }

        return sb.toString().trim();
    }

    public static String joinToString(Collection<String> words) {
        return joinToString(words.toArray(new String[0]));
    }

    public static String joinToString(String[] words) {
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            sb.append(word).append(" ");
        }

        return sb.toString().trim();
    }

    // Generate random words from the characters of the given word
    public static List<String> getRandomizedVariants(String word, int count) {
        List<String> variants = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            variants.add(getScrambledWord(word));
        }

        return variants;
    }

    // Create a scrambled version of the given word
    public static String getScrambledWord(String word) {
        char[] characters = word.toCharArray();
        int randomIndex = (int) (Math.random() * (characters.length - 1));
        char temp = characters[randomIndex];
        characters[randomIndex] = characters[randomIndex + 1];
        characters[randomIndex + 1] = temp;
        return joinToString(characters, "");
    }

}
