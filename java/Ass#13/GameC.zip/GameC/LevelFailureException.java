public class LevelFailureException extends IllegalStateException {
    public LevelFailureException() {
    }

    public LevelFailureException(String s) {
        super(s);
    }
}
