import java.util.*;

public class Dictionary {

    private static final Dictionary instance = new Dictionary();

    private final Map<String, Set<String>> dictionary = new HashMap<>();

    private Dictionary() {
        dictionary.put("late", new HashSet<>(Arrays.asList("tale", "teal")));
        dictionary.put("pate", new HashSet<>(Arrays.asList("peat", "tape")));
        dictionary.put("pare", new HashSet<>(Arrays.asList("pear", "reap")));
        dictionary.put("parse", new HashSet<>(Arrays.asList("asper", "pares", "pears", "prase")));
        dictionary.put("rate", new HashSet<>(Arrays.asList("tare", "tear")));
        dictionary.put("tales", new HashSet<>(Arrays.asList("stale", "slate", "tesla", "steal", "least")));
        dictionary.put("east", new HashSet<>(Arrays.asList("eats", "sate", "seat", "seta", "teas")));
        dictionary.put("alerts", new HashSet<>(Arrays.asList("alters", "artels", "estral", "laster", "ratels", "salter", "slater", "staler")));
        dictionary.put("post", new HashSet<>(Arrays.asList("pots", "spot", "stop", "tops")));
        dictionary.put("alerting", new HashSet<>(Arrays.asList("altering", "integral", "relating", "triangle")));
        dictionary.put("steak", new HashSet<>(Arrays.asList("skate", "stake", "takes")));
        dictionary.put("live", new HashSet<>(Arrays.asList("evil", "veil", "vile")));
        dictionary.put("meat", new HashSet<>(Arrays.asList("mate", "team", "tame")));
        dictionary.put("insert", new HashSet<>(Arrays.asList("estrin", "inerts", "inters", "niters", "nitres", "sinter", "triens", "trines")));
        dictionary.put("laser", new HashSet<>(Arrays.asList("earls", "reals", "rales", "lares")));
        dictionary.put("lapse", new HashSet<>(Arrays.asList("peals", "pleas", "pales", "sepal")));
        dictionary.put("angle", new HashSet<>(Arrays.asList("angel", "glean", "genal")));
        dictionary.put("super", new HashSet<>(Arrays.asList("purse", "sprue")));
        dictionary.put("scrape", new HashSet<>(Arrays.asList("capers", "crapes", "spacer", "pacers")));
        dictionary.put("retains", new HashSet<>(Arrays.asList("stainer", "starnie", "resiant", "nastier", "retinas")));
    }

    public static Dictionary getInstance() {
        return instance;
    }

    public Map<String, Set<String>> getDictionary() {
        return dictionary;
    }
}
