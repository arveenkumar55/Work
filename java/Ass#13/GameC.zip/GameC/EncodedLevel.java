import java.util.*;

public class EncodedLevel implements Level {

    private final Random random;
    private final String[] symbols = new String[]{"!", "@", "#", "$", "%", "&", "*"};
    private final Map<String, Set<String>> dictionary;
    private final String sentence;
    private final String encoded;

    public EncodedLevel(final Dictionary dictionary) {
        this.dictionary = dictionary.getDictionary();
        random = new Random();
        sentence = generateSentence(5);
        encoded = hashCode(sentence);
    }

    @Override
    public String getName() {
        return "Encoded Words";
    }

    @Override
    public String getTitle() {
        return "The Word And Number Game";
    }

    @Override
    public String getDescription() {
        return "At this level, you are given a set of encoded words. Your task is to input the decoded version of the\n" +
                "words that you can come up with.\n" +
                "You win if all words are correctly decoded.\n" +
                "Sample for you: 8*,18@0#22!,0%,3@14&6^ is the decoded as “i saw a dog”";
    }

    @Override
    public void play(boolean isSecondChance) throws LevelFailureException {
        System.out.println("Your encoded words: " + encoded);
        if (isSecondChance)
            System.out.println("Please give your input (Second Chance): ");
        else
            System.out.println("Please give your input: ");

        if (isDebug) System.out.println("DEBUG: " + sentence);
        Scanner scanner = new Scanner(System.in);
        String sentence = scanner.nextLine();
        if (!isValid(this.sentence, sentence)) {
            throw new LevelFailureException("Fail! all inputted words must be valid");
        }
    }

    private boolean isValid(String sentence, String input) {
        return sentence.equals(input);
    }

    private String generateSentence(int wordCount) {
        Set<String> words = new HashSet<>();
        while (words.size() < wordCount) {
            words.add(dictionary.keySet().toArray()[random.nextInt(dictionary.size())].toString());
        }

        return StringUtils.joinToString(words);
    }

    private String hashCode(String sentence) {
        char[] chars = sentence.toCharArray();
        StringBuilder builder = new StringBuilder();
        for (char ch : chars) {
            builder.append(ch - 'a').append(symbols[random.nextInt(symbols.length)]);
        }

        return builder.toString();
    }
}
