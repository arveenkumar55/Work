import java.util.*;

public class AnagramLevel implements Level {

    private final Random random;
    private final Map<String, Set<String>> dictionary;
    private final String selected;

    public AnagramLevel(final Dictionary dictionary) {
        this.dictionary = dictionary.getDictionary();
        random = new Random();
        selected = getWord();
    }

    @Override
    public String getName() {
        return "Anagram";
    }

    @Override
    public String getTitle() {
        return "The Word And Number Game";
    }

    @Override
    public String getDescription() {
        return "At this level, you are given a set of letters. Your task is to input all valid words that you can come up\n" +
                "from the letters separated by spaces. Note that each word must use all letters.\n" +
                "You win if there are at least two correct words.";
    }

    @Override
    public void play(boolean isSecondChance) throws LevelFailureException {
        System.out.println("Your letters: " + StringUtils.joinToString(selected.toCharArray()));
        if (isSecondChance)
            System.out.println("Please give your input (Second Chance): ");
        else
            System.out.println("Please give your input: ");

        if (isDebug) System.out.println("DEBUG: " + StringUtils.joinToString(dictionary.get(selected)));
        Scanner scanner = new Scanner(System.in);
        String[] words = scanner.nextLine().split(" ");
        if (words.length >= 2 && !isValid(selected, words)) {
            throw new LevelFailureException(
                    String.format(
                            "Fail! at least two inputted words must be valid\nYour words: %s are invalid",
                            StringUtils.joinToString(getInvalid(selected, words))
                    )
            );
        }
    }

    private boolean isValid(String base, String[] words) {
        return words.length - getInvalid(base, words).size() >= 2;
    }

    private List<String> getInvalid(String base, String[] words) {
        Set<String> pool = dictionary.get(base);
        List<String> invalid = new ArrayList<>();
        for (String word : words) {
            if (!pool.contains(word)) invalid.add(word);
        }

        return invalid;
    }

    private String getWord() {
        return dictionary.keySet().toArray()[random.nextInt(dictionary.size())].toString();
    }

}
