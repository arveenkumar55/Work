import java.util.Arrays;
import java.util.List;

public class Game {

    private final Dictionary dictionary = Dictionary.getInstance();
    private final List<Level> levels = Arrays.asList(
            new AnagramLevel(dictionary),
            new ScrambledLevel(dictionary),
            new EncodedLevel(dictionary)
    );
    private int currentLevel = 0;
    private boolean isSecondChance = false;
    private boolean isGameOver = false;

    public static void main(String[] args) {
        Game game = new Game();
        while (!game.isGameOver) {
            game.play();
        }

        if (!game.isGameWon()) System.out.println("Game Over");
        else System.out.println("Congratulations! You won the game!");
    }

    public void play() {
        System.out.println("---------------------------------");
        if (currentLevel >= levels.size()) {
            isGameOver = true;
            return;
        }

        Level level = levels.get(currentLevel);
        showLevelIntroduction(level);
        while (!isGameOver) {
            try {
                level.play(isSecondChance);
                currentLevel++;
                if (currentLevel >= levels.size()) {
                    isGameOver = true;
                }

                isSecondChance = false;
                System.out.printf("Congratulations! You completed level %d successfully!%n", currentLevel);
                break;
            } catch (LevelFailureException e) {
                System.out.println(e.getMessage());
                if (isSecondChance) isGameOver = true;
                isSecondChance = true;
                System.out.println("***");
            }
        }
    }

    private void showLevelIntroduction(Level level) {
        System.out.printf("Level %d: %n", currentLevel + 1);
        System.out.printf("Welcome to \"%s\"%n", level.getTitle());
        System.out.printf("Level %d: %s%n", currentLevel + 1, level.getName());
        System.out.println(level.getDescription());
        System.out.println("***");
    }

    public boolean isGameWon() {
        return isGameOver && !isSecondChance && currentLevel == 3;
    }

    public void reset() {
        currentLevel = 0;
        isGameOver = false;
    }
}
