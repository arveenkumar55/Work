import java.util.*;

public class ScrambledLevel implements Level {

    private final Random random;
    private final Map<String, Set<String>> dictionary;
    private final Map<String, String> scrambled;

    public ScrambledLevel(final Dictionary dictionary) {
        this.dictionary = dictionary.getDictionary();
        random = new Random();
        scrambled = scrambleWords(getWords());
    }

    @Override
    public String getName() {
        return "Scrambled Words";
    }

    @Override
    public String getTitle() {
        return "The Word And Number Game";
    }

    @Override
    public String getDescription() {
        return "At this level, you are given a set of scrambled words. Your task is to input a non-scrambled version of\n" +
                "the words that you can come up with, separated by spaces.\n" +
                "You win if there are at least three correct words.";
    }

    @Override
    public void play(boolean isSecondChance) throws LevelFailureException {
        System.out.println("Your scrambled words: " + StringUtils.joinToString(scrambled.keySet()));
        if (isSecondChance)
            System.out.println("Please give your input (Second Chance): ");
        else
            System.out.println("Please give your input: ");

        if (isDebug) System.out.println("DEBUG: " + StringUtils.joinToString(scrambled.values()));
        Scanner scanner = new Scanner(System.in);
        String[] words = scanner.nextLine().split(" ");
        if (words.length >= 2 && !isValid(scrambled, words)) {
            throw new LevelFailureException(
                    String.format(
                            "Fail! at least two inputted words must be valid\nYour words: %s are invalid",
                            StringUtils.joinToString(getInvalid(scrambled, words))
                    )
            );
        }
    }

    private boolean isValid(Map<String, String> base, String[] words) {
        return words.length - getInvalid(base, words).size() >= 3;
    }

    private List<String> getInvalid(Map<String, String> base, String[] words) {
        Set<String> pool = new HashSet<>(base.values());
        List<String> invalid = new ArrayList<>();
        for (String word : words) {
            if (!pool.contains(word)) invalid.add(word);
        }

        return invalid;
    }

    private Set<String> getWords() {
        Set<String> words = new HashSet<>();
        while (words.size() < 5) {
            words.add(dictionary.keySet().toArray()[random.nextInt(dictionary.size())].toString());
        }

        return words;
    }

    private Map<String, String> scrambleWords(Set<String> words) {
        Map<String, String> scrambled = new HashMap<>();
        for (String word : words) scrambled.put(StringUtils.getScrambledWord(word), word);
        return scrambled;
    }
}
