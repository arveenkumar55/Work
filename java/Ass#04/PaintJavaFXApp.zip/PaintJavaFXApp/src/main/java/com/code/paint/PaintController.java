package com.code.paint;

import com.code.paint.properties.SimpleErrorProperty;
import com.code.paint.shapes.Circle;
import com.code.paint.shapes.GeometricObject;
import com.code.paint.shapes.Rectangle;
import com.code.paint.shapes.ShapeFactory;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

public class PaintController {

    private final List<GeometricObject> shapes = new ArrayList<>();

    private Class<? extends GeometricObject> selectedShape = Circle.class;
    private RGBColor color = new RGBColor(0, 0, 255);
    private int brushSize = 40;

    private StringProperty helpText = new SimpleStringProperty("Press Draw or Click for a Circle");
    private SimpleStringProperty errorFieldColor = new SimpleStringProperty("#000000");
    private SimpleErrorProperty errorMessage = new SimpleErrorProperty(errorFieldColor);

    @FXML
    private Canvas canvas;

    @FXML
    private Text errorTextView;

    @FXML
    private TextField brushSizeTextField;
    @FXML
    private TextField colorRedTextField;
    @FXML
    private TextField colorGreenTextField;
    @FXML
    private TextField colorBlueTextField;

    @FXML
    private TextField locationXTextField;
    @FXML
    private TextField locationYTextField;

    @FXML
    void initialize() {
        cleanCanvas();
        configureTextFields();
    }

    private void configureTextFields() {
        brushSizeTextField.setText(String.valueOf(brushSize));
        setTextFieldListener(
                brushSizeTextField,
                it -> it > 0,
                it -> this.brushSize = it.orElse(0),
                "Invalid Brush Size"
        );

        colorRedTextField.setText(String.valueOf(color.getRed()));
        colorGreenTextField.setText(String.valueOf(color.getGreen()));
        colorBlueTextField.setText(String.valueOf(color.getBlue()));
        setColorListener(colorRedTextField, it -> it::setRed);
        setColorListener(colorGreenTextField, it -> it::setGreen);
        setColorListener(colorBlueTextField, it -> it::setBlue);
    }

    @FXML
    void onCanvasClicked(MouseEvent event) {
        drawShape(event.getX(), event.getY());
        this.errorMessage.set("");
    }

    @FXML
    void onRectangleSelect() {
        selectedShape = Rectangle.class;
        helpText.set("Press Draw or Click for a Rectangle");
    }

    @FXML
    void onCircleSelect() {
        selectedShape = Circle.class;
        helpText.set("Press Draw or Click for a Circle");
    }

    @FXML
    private void draw() {
        try {
            double x = Integer.parseInt(locationXTextField.getText());
            double y = Integer.parseInt(locationYTextField.getText());

            if (x <= canvas.getWidth() && x >= 0 && y <= canvas.getHeight() && y >= 0) {
                drawShape(x, y);
                this.errorMessage.set("");
            } else {
                this.errorMessage.set("Invalid location coordinates");
            }
        } catch (NumberFormatException e) {
            this.errorMessage.set("Invalid location coordinates");
        }
    }

    @FXML
    private void undo() {
        cleanCanvas();
        if (!shapes.isEmpty()) {
            shapes.remove(shapes.size() - 1);
            GraphicsContext context = canvas.getGraphicsContext2D();
            for (GeometricObject shape : shapes) {
                shape.draw(context);
            }
        }
    }

    private void setColorListener(TextField field, Function<RGBColor.Builder, Consumer<Integer>> color) {
        setTextFieldListener(field, it -> it >= 0 && it <= 255, it -> {
            RGBColor.Builder builder = this.color.clone();
            color.apply(builder).accept(it.orElse(0));
            this.color = builder.build();
        }, "Invalid " + field.getId().split("Text")[0]);
    }

    private void setTextFieldListener(
            TextField field,
            Function<Integer, Boolean> condition,
            Consumer<Optional<Integer>> onResult,
            String errorMessage
    ) {
        field.textProperty().addListener((prop, old, value) -> {
            try {
                int val = Integer.parseInt(value);
                if (condition.apply(val)) {
                    onResult.accept(Optional.of(val));
                    this.errorMessage.set("");
                } else {
                    onResult.accept(Optional.empty());
                    this.errorMessage.set(Optional.of(errorMessage).orElse("Error occurred"));
                }
            } catch (NumberFormatException e) {
                this.errorMessage.set(Optional.of(errorMessage).orElse(e.getMessage()));
            }
        });
    }

    private void drawShape(double x, double y) {
        GeometricObject shape = ShapeFactory.get(selectedShape, x, y, brushSize, color.toColor());
        shape.draw(canvas.getGraphicsContext2D());
        shapes.add(shape);
    }

    private void cleanCanvas() {
        GraphicsContext context = canvas.getGraphicsContext2D();
        context.setFill(Color.WHITE);
        context.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    public String getHelpText() {
        return helpText.get();
    }

    public StringProperty helpTextProperty() {
        return helpText;
    }

    public String getErrorMessage() {
        return errorMessage.get();
    }

    public StringProperty errorMessageProperty() {
        return errorMessage;
    }

    public String getErrorFieldColor() {
        return errorFieldColor.get();
    }

    public SimpleStringProperty errorFieldColorProperty() {
        return errorFieldColor;
    }
}