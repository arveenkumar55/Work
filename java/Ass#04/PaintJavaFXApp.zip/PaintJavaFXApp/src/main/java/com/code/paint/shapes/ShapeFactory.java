package com.code.paint.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class ShapeFactory {

    public static GeometricObject get(
            Class<? extends GeometricObject> clazz,
            double x,
            double y,
            double brushSize,
            Color color
    ) {
        if (clazz.equals(Rectangle.class)) return new Rectangle(x, y, brushSize, color);
        else if (clazz.equals(Circle.class)) return new Circle(x, y, brushSize, color);
        else throw new IllegalArgumentException("No such class supported: " + clazz);
    }

}
