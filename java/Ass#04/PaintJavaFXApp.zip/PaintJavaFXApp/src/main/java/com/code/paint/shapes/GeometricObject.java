package com.code.paint.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public abstract class GeometricObject implements Drawable {

    protected final double x;
    protected final double y;
    protected final double brushSize;
    protected final Color color;

    public GeometricObject(double x, double y, double brushSize, Color color) {
        this.x = x;
        this.y = y;
        this.brushSize = brushSize;
        this.color = color;
    }

    abstract String getName();

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getBrushSize() {
        return brushSize;
    }

    public Color getColor() {
        return color;
    }

}
