package com.code.paint.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Rectangle extends GeometricObject {
    private final double size;

    public Rectangle(double x, double y, double brushSize, Color color) {
        super(x, y, brushSize, color);
        size = brushSize / 2;
    }

    @Override
    public void draw(GraphicsContext context) {
        context.setFill(color);
        context.fillRect(x - size, y - size, brushSize, brushSize);
    }

    @Override
    String getName() {
        return "Rectangle";
    }
}
