package com.code.paint.shapes;

import javafx.scene.canvas.GraphicsContext;

public interface Drawable {
    void draw(GraphicsContext context);
}
