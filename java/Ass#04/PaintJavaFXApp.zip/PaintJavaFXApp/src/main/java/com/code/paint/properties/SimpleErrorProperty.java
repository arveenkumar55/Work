package com.code.paint.properties;

import javafx.beans.property.SimpleStringProperty;
import javafx.scene.text.Text;

public class SimpleErrorProperty extends SimpleStringProperty {

    private SimpleStringProperty errorFieldColor;
    private final String defaultColor;
    private final String errorColor;


    public SimpleErrorProperty(SimpleStringProperty errorFieldColor, String defaultColor, String errorColor) {
        super("No Errors");
        this.errorFieldColor = errorFieldColor;
        this.defaultColor = defaultColor;
        this.errorColor = errorColor;
    }

    public SimpleErrorProperty(SimpleStringProperty errorFieldColor) {
        this(errorFieldColor, "WHITE", "RED");
    }

    @Override
    public void set(String s) {
        if (!s.isEmpty())
            errorFieldColor.set(errorColor);
        else {
            errorFieldColor.set(defaultColor);
            s = "No errors";
        }
        super.set(s);
    }
}
