package com.code.paint;

import javafx.scene.paint.Color;

public class RGBColor {

    private final double red;
    private final double green;
    private final double blue;

    public RGBColor(int red, int green, int blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    Color toColor() {
        return Color.color(red / 255, green / 255, blue / 255);
    }

    public int getRed() {
        return (int) red;
    }

    public int getGreen() {
        return (int) green;
    }

    public int getBlue() {
        return (int) blue;
    }

    public Builder clone() {
        return new Builder(red, green, blue);
    }

    public static class Builder {
        private int red;
        private int green;
        private int blue;

        private Builder(double red, double green, double blue) {
            this.red = (int) red;
            this.green = (int) green;
            this.blue = (int) blue;
        }

        public Builder setRed(int red) {
            this.red = red;
            return this;
        }

        public Builder setGreen(int green) {
            this.green = green;
            return this;
        }

        public Builder setBlue(int blue) {
            this.blue = blue;
            return this;
        }

        public RGBColor build() {
            return new RGBColor(red, green, blue);
        }
    }
}
