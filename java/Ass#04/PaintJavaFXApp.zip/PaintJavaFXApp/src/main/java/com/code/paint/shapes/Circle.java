package com.code.paint.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Circle extends GeometricObject {
    private final double size;

    public Circle(double x, double y, double brushSize, Color color) {
        super(x, y, brushSize, color);
        size = brushSize / 2;
    }

    @Override
    public void draw(GraphicsContext context) {
        context.setFill(color);
        context.fillOval(x - size, y - size, brushSize, brushSize);
    }

    @Override
    String getName() {
        return "Circle";
    }
}
