module com.code.paint {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.code.paint to javafx.fxml;
    exports com.code.paint;
}