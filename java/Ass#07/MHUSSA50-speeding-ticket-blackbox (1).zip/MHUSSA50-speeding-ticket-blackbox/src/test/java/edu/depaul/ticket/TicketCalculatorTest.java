package edu.depaul.ticket;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TicketCalculatorTest {

    private TicketCalculator calculator;

    @BeforeEach
    void setup() {

        // This loaded a default set of drivers.  See the PDF
        // for details
        calculator = new TicketCalculator();
    }

    @Test
    @DisplayName("Verify the system is running")
    void verifyInstructionsAreProduced() {
        Instruction instr = calculator.computeCost("DL12345", 25, 33, 2);
        assertEquals(Instruction.class, instr.getClass());
    }

    @Test
    @DisplayName("Check if the result if the speed is 1 MPH over the legal speed and the driver was given a ticket 1 years ago")
    void checkSpeedFor10MPHMin1Year() {
        Instruction instr = calculator.computeCost("DL22222", 45, 46, 2);
        assertEquals(instr.fine(), 0, 1e-2);
    }

    @Test
    @DisplayName("Check if the result if the speed is 10 MPH over the legal speed and the driver was given a ticket 1 years ago")
    void checkSpeedFor10MPHMax1Year() {
        Instruction instr = calculator.computeCost("DL22222", 45, 55, 2);
        assertEquals(instr.fine(), 0, 1e-2);
    }

    @Test
    @DisplayName("Check if the result if the speed is 1 MPH over the legal speed and the driver was given a ticket 11 months ago")
    void checkSpeedFor10MPHMin11Month() {
        Instruction instr = calculator.computeCost("DL54321", 45, 46, 2);
        assertEquals(instr.fine(), 25, 1e-2);
    }

    @Test
    @DisplayName("Check if the result if the speed is 10 MPH over the legal speed and the driver was given a ticket 11 months ago")
    void checkSpeedFor10MPHMax11Month() {
        Instruction instr = calculator.computeCost("DL54321", 45, 55, 2);
        assertEquals(instr.fine(), 25, 1e-2);
    }
}
