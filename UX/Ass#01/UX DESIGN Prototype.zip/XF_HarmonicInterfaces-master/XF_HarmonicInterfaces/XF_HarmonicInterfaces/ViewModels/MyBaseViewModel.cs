﻿using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace XF_HarmonicInterfaces.ViewModels
{
    public class MyBaseViewModel : BaseViewModel
    {
        public virtual void Initialize(object parameter)
        {

        }
    }
}
