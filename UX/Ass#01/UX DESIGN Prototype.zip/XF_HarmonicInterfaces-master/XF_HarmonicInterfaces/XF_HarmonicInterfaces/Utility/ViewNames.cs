﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XF_HarmonicInterfaces.Utility
{
    public class ViewNames
    {
        public const string ExercisePage = "ExercisePage";
        public const string ExerciseDetailPage = "ExerciseDetailPage";
    }
}
