﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XF_HarmonicInterfaces.Helpers
{
    public enum ThemeType
    {
        Light,
        Dark
    }
}
