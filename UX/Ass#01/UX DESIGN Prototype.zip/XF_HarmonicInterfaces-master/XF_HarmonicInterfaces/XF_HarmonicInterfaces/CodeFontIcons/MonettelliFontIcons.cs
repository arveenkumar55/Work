﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XF_HarmonicInterfaces.CodeFontIcons
{
    static class MonettelliFontIcons
    {
        public const string icon_search = "\ue800";
        public const string icon_tab_today = "\ue801";
        public const string icon_tab_gym = "\ue802";
        public const string icon_tab_settings = "\ue803";
        public const string icon_lock = "\ue804";
    }
}
