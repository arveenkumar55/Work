//
// Created by one on 3/28/22.
//

#ifndef BookStore_h
#define BookStore_h


#include "Book.h"

class BookStore {
private:
    int bookCount;
    int bookCapacity;
    Book *books;

    Book *getWithIsbn(std::string isbn);

public:
    BookStore();

    void addBook(Book book);

    void sellBook(std::string isbn);

    void searchByTitle(std::string title);

    void searchByAuthor(std::string author);

    void searchByISBN(std::string isbn);

    int getBookCount() const;

    Book *getBooks() const;
};


#endif //BookStore_h
