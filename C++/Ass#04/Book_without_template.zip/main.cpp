#include <iostream>
#include <climits>
#include "BookStore.h"

int prompt_int(const char* prompt) {
    int value;
    std::cout << prompt;
    std::cin >> value;
    std::cin.clear();
    std::cin.ignore(INT_MAX, '\n');
    return value;
}

std::string prompt(const char* prompt) {
    std::string value;
    std::cout << prompt;
    std::getline(std::cin, value);
    return value;
}

int showMainMenu() {
    std::cout << "Enter choice:" << std::endl;
    std::cout << "\t1 to add book" << std::endl;
    std::cout << "\t2 to sell book" << std::endl;
    std::cout << "\t3 to search by Title" << std::endl;
    std::cout << "\t4 to search by author" << std::endl;
    std::cout << "\t5 to search by isbn" << std::endl;
    std::cout << "\t6 to quit?";

    return prompt_int("");
}

void addBook(BookStore& store) {
    std::string title = prompt("Enter title: ");
    std::string author = prompt("Enter author: ");
    std::string isbn = prompt("Enter isbn: ");
    std::string publisher = prompt("Enter publisher: ");
    std::string year = prompt("Enter year: ");
    int count = prompt_int("Enter count: ");
    int price = prompt_int("Enter price: ");

    store.addBook(Book(isbn, author, title, year, publisher, count, price));
}

void sellBook(BookStore& store) {
    std::string isbn = prompt("Enter isbn: ");
    try {
        store.sellBook(isbn);
    } catch (std::exception& e) {
        std::cout << e.what() << std::endl;
    }
}

void searchByTitle(BookStore& store) {
    std::string title = prompt("Enter title: ");
    store.searchByTitle(title);
}

void searchByAuthor(BookStore& store) {
    std::string author = prompt("Enter author: ");
    store.searchByAuthor(author);
}

void searchByIsbn(BookStore& store) {
    std::string isbn = prompt("Enter isbn: ");
    store.searchByISBN(isbn);
}

int main() {
    BookStore store;
    bool quit = false;
    while (!quit) {
        int choice = showMainMenu();
        switch (choice) {
            case 1:
                addBook(store);
                break;
            case 2:
                sellBook(store);
                break;
            case 3:
                searchByTitle(store);
                break;
            case 4:
                searchByAuthor(store);
                break;
            case 5:
                searchByIsbn(store);
                break;
            case 6:
                quit = true;
                break;
            default:
                std::cout << "Invalid choice" << std::endl;
        }
    }

    return 0;
}
