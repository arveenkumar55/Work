#include "BookStore.h"
#include <stdexcept>
#include <iostream>


// Class Functions
Book *BookStore::getWithIsbn(std::string isbn) {
    // Iterate through the books
    for (int i = 0; i < bookCount; i++) {
        // If the isbn matches, return the book
        if (books[i].getIsbn() == isbn) return &books[i];
    }

    // If no book was found, return nullptr
    return nullptr;
}

BookStore::BookStore() {
    bookCount = 0;
    bookCapacity = 200;
    books = new Book[200];
}

Book *BookStore::getBooks() const {
    return books;
}

int BookStore::getBookCount() const {
    return bookCount;
}

void BookStore::addBook(Book book) {
    // Check if book is already in store
    Book *ref = getWithIsbn(book.getIsbn());
    // If book is in store, increase quantity
    if (ref != nullptr) {
        // Update the count
        ref->setCount(ref->getCount() + book.getCount());
    } else {
        // Add it to the store and update the count
        books[bookCount] = book;
        bookCount++;
    }
}

void BookStore::sellBook(std::string isbn) {
    // First, find the reference to the book we are selling
    Book *book = getWithIsbn(isbn);
    if (book != nullptr) {
        // Now, if the reference is not null, we can sell the book
        // Check if the count is greater than 0
        if (book->getCount() > 0) {
            // Reduce the count
            book->setCount(book->getCount() - 1);
        } else {
            // Now since we don't have a copy of the book
            // Throw an exception
            throw std::invalid_argument("Out of stock.");
        }
    } else {
        // Now since no such book exists
        // Throw an exception
        throw std::invalid_argument("Book not found.");
    }
}

void BookStore::searchByTitle(std::string title) {
    bool found = false;
    for (int i = 0; i < bookCount; i++) {
        // Check if the title contains the search string
        if (books[i].getTitle().find(title) != std::string::npos) {
            // If it does, print the book
            found = true;
            std::cout << books[i].toString() << std::endl;
        }
    }

    if (!found) {
        std::cout << "No result found." << std::endl;
    }
}

void BookStore::searchByAuthor(std::string author) {
    bool found = false;
    for (int i = 0; i < bookCount; i++) {
        // Check if the author contains the search string
        if (books[i].getAuthor().find(author) != std::string::npos) {
            // If we find a match, print the book
            found = true;
            std::cout << books[i].toString() << std::endl;
        }
    }

    // If no result found
    if (!found) {
        std::cout << "No result found." << std::endl;
    }
}

void BookStore::searchByISBN(std::string isbn) {
    Book *book = getWithIsbn(isbn);
    // Check if the book exists
    if (book != nullptr) {
        std::cout << book->toString() << std::endl;
    } else {
        // Now since no such book exists
        std::cout << "No result found." << std::endl;
    }
}


