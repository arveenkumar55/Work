#include "BookStore.h"
#include <stdexcept>
#include <iostream>

// Util functions

template<typename T>
int indexOf(T *array, T value, int size) {
    for (int i = 0; i < size; i++) {
        if (array[i] == value) return i;
    }

    return -1;
}

// Class Functions


Book *BookStore::getWithIsbn(std::string isbn) {
    for (int i = 0; i < bookCount; i++) {
        if (books[i].getIsbn() == isbn) return &books[i];
    }

    return nullptr;
}

BookStore::BookStore() {
    bookCount = 0;
    bookCapacity = 200;
    books = new Book[200];
}

Book *BookStore::getBooks() const {
    return books;
}

int BookStore::getBookCount() const {
    return bookCount;
}

void BookStore::addBook(Book book) {
    Book *ref = getWithIsbn(book.getIsbn());
    if (ref != nullptr) {
        ref->setCount(ref->getCount() + book.getCount());
    } else {
        books[bookCount] = book;
        bookCount++;
    }
}

void BookStore::sellBook(std::string isbn) {
    // First, find the reference to the book we are selling
    Book *ref = getWithIsbn(isbn);
    if (ref != nullptr) {
        // Now, if the reference is not null, we can sell the book
        // Check if the count is greater than 0
        if (ref->getCount() > 0) {
            // Reduce the count
            ref->setCount(ref->getCount() - 1);
        } else {
            // Now since we don't have a copy of the book
            // Throw an exception
            throw std::invalid_argument("Out of stock.");
        }
    } else {
        // Now since no such book exists
        // Throw an exception
        throw std::invalid_argument("Book not found.");
    }
}

void BookStore::searchByTitle(std::string title) {
    bool found = false;
    for (int i = 0; i < bookCount; i++) {
        if (books[i].getTitle().find(title) != std::string::npos) {
            found = true;
            std::cout << books[i].toString() << std::endl;
        }
    }

    if (!found) {
        std::cout << "No result found." << std::endl;
    }
}

void BookStore::searchByAuthor(std::string author) {
    bool found = false;
    for (int i = 0; i < bookCount; i++) {
        if (books[i].getAuthor().find(author) != std::string::npos) {
            found = true;
            std::cout << books[i].toString() << std::endl;
        }
    }

    if (!found) {
        std::cout << "No result found." << std::endl;
    }
}

void BookStore::searchByISBN(std::string isbn) {
    Book *book = getWithIsbn(isbn);
    if (book != nullptr) {
        std::cout << book->toString() << std::endl;
    } else {
        std::cout << "No result found." << std::endl;
    }
}


