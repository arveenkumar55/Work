#include    <stdlib.h>
#include    <stdio.h>
#include    <string.h>
#include    <unistd.h>
#include    <signal.h>
#include    <wait.h>

const float SUCCESS_RATE = 0.6;

const char *NAME_ARRAY[] = {"Alice", "Bob", "Cathy", "David"};

int waitTimeInSecs = 1;

int shouldRun = 1;

int nameIndex;

pid_t childPid;    // Only used in partner1.c


//  PURPOSE:  To return a pseudo-random floating point number uniformly
//	distributed in [0.0 .. 1.0) when drand48() is acting-up.  No parameters.
float rand0To1() {
    int remainder = rand() % 1024;

    return (((float) remainder) / 1024);
}


void sigUsr1Handler(int sigNum) {
    sleep(waitTimeInSecs);
    float rand = rand0To1();
    if (rand <= SUCCESS_RATE) {
        printf("%s \"Caught it!  Here it comes, catch!\"\n", NAME_ARRAY[nameIndex]);
        printf("%s takes one step back.\n", NAME_ARRAY[nameIndex]);
        kill(childPid, SIGUSR1);
    } else {
        printf("%s (Splash!)\n", NAME_ARRAY[nameIndex]);
        printf("%s \"Dang!  I'm all wet!\"\n", NAME_ARRAY[nameIndex]);
        kill(childPid, SIGUSR2);
        shouldRun = 0;
    }
}

void sigUsr2Handler(int sigNum) {
    printf("%s \"Okay, I'll go.\"\n", NAME_ARRAY[nameIndex]);
    shouldRun = 0;
}

int getPlayerIndex(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage:\tpartner1 (nameIndex)\n");
        exit(EXIT_FAILURE);
    }

    int player = atoi(argv[1]);
    if (player < 0 || player > 2) {
        fprintf(stderr, "nameIndex must be in [0,1,2]\n");
        exit(EXIT_FAILURE);
    }

    return player;
}

void configureSignal(int signal, void (*funcPtr)(int)) {
    struct sigaction sa;
    memset(&sa, '\0', sizeof(struct sigaction));
    sigemptyset(&sa.sa_mask);

    sa.sa_flags = SA_SIGINFO | SA_RESTART;

    sa.sa_handler = funcPtr;
    sigaction(signal, &sa, NULL);
}

int main(int argc, char *argv[]) {
    srand(getpid());
    nameIndex = getPlayerIndex(argc, argv);

    configureSignal(SIGUSR1, sigUsr1Handler);
    configureSignal(SIGUSR2, sigUsr2Handler);

    if ((childPid = fork()) == -1) {
        fprintf(stderr, "Cannot find partner2\n");
        exit(EXIT_SUCCESS);
    } else if (childPid == 0) {
        char buffer[15];
        sprintf(buffer, "%d", nameIndex + 1);
        execl("partner2", "partner2", buffer, NULL);
        printf("Return not expected. Must be an execl() error.\n");
    }

    sleep(1);
    printf("%s \"Here it comes, catch!\"\n", NAME_ARRAY[nameIndex]);
    kill(childPid, SIGUSR1);

    while (shouldRun) sleep(1);

    wait(&childPid);
    return (EXIT_SUCCESS);
}
