#ifndef DLL_HEADER_FILE
#define DLL_HEADER_FILE

#include <iostream>
#ifndef D_Header_File
#include "DNode.h"
#endif

/*=======================================================================*/
//								Class DLL
/*=======================================================================*/
template <class T> class DLL{
private:
	DNode<T>* h;
	DNode<T>* t;
public:
	//constructors
	DLL();
	~DLL();
	DLL(DLL& ls);//copy constructor
	
	//Get Information
	bool isEmpty();
	void print();
	T getHead();
	T getTail();
	DNode<T>* getHeadNode();
	DNode<T>* getTailNode();
	bool search(T& x);
	
	
	//Adding
	void addtoHead(T& data);
	void addtoTail(T& data);
	void insert(T& v);
	
	//Deleting
	void clearAll();
	void delHead();
	void delTail();
	bool delNode(T& x);

	//stack related
	T getLast() {return getTail();}
	void delLast() { delTail();}
	void addLast(T& el){addtoTail(el);}	

	//Queue related
	T getFirst() {return getHead();}


};

template <class T> DLL<T>::DLL() { 	
	h=t=NULL;
}

template <class T> DLL<T>::~DLL(){
	clearAll();
}

template <class T>
DLL<T>::DLL(DLL& ls){//copy constructor=> DLL x=y;
	t=ls.t;h=ls.h;
}

// get Information
template <class T> 
bool  DLL<T>::isEmpty(){
	return h==NULL;
}

template <class T> 
void  DLL<T>::print(){
	DNode<T> *p=h;
	std::cout<<"List=";
	while(p!=NULL)	{
		std::cout<<p->data<<",";
		p=p->next;
	}
	std::cout<<".\n";
}

template <class T> 
T DLL<T>::getHead(){
	if (isEmpty()) exit(0);
	return h->data;
}

template <class T>
T DLL<T>::getTail(){
	if (isEmpty()) exit(0);
	return t->data;
}

template <class T>
DNode<T>* DLL<T>::getHeadNode(){ return h;}

template <class T>
DNode<T>* DLL<T>::getTailNode(){ return t;}

template <class T>
bool DLL<T>::search(T& x){
	DNode<T>* k=h;
	while (k!=NULL)
	{
		if (k->data==x)
			return true;
		k=k->next;
	}
	return false;
}

//deleting
template <class T> 
void  DLL<T>::clearAll(){
	//while (! isEmpty()) delHead();
	DNode<T>* p=NULL;
	while (!isEmpty()){//std::cout<<"Destr"<<h->data<<std::endl;
		p=h;
		h=h->next;
		delete p;
	}
	h=t=NULL;
}

template <class T> 
void DLL<T>:: delHead(){
	if(isEmpty()) return;
	DNode<T>*z=h;
	if (h==t) {
		h=t=NULL; 
	}
	else{
		h=h->next;
		h->prev=NULL;
	}
	delete z;

}

template <class T> 
void DLL<T>:: delTail(){
	if(isEmpty()) return;
	DNode<T>*z=t;
	if (h==t) {h=t=NULL; }
	else
	{
	   t=t->prev;
	   t->next =NULL;
        }
	delete z;
}

template <class T> 
bool DLL<T>:: delNode(T& v){
	if (isEmpty()) return false;
	if(h->data ==v) {delHead(); return true;}
	if(t->data ==v) {delTail(); return true;}
	DNode<T>*k=h->next;
	while(k!=NULL)
	{
		if(k->data==v)
		{
			DNode<T>* pred = k->prev;
			DNode<T>* succ = k->next;
			pred->next=k->next;
			succ->prev = pred;
			delete k;
			return true;
		}
		else
		k=k->next;
	}
	return false;
}	

// Adding
template <class T> 
void DLL<T>::addtoHead(T& v)
{
	DNode<T>* z= new DNode<T>(v,h,NULL);
	if (h!=NULL) h->prev=z;
	h=z;
	if (t==NULL) t=z;

}

template <class T> 
void DLL<T>::addtoTail(T& v)
{
	DNode<T>* z= new DNode<T>(v,NULL,t);
	if (t!=NULL) t->next=z;
	t=z;
	if (h==NULL) h=z;
}

template <class T> 
void  DLL<T>::insert(T& v){
	if(isEmpty())  {addtoHead(v); return;}
	if(h->data>=v) {addtoHead(v); return;}
	if(t->data<=v) {addtoTail (v); return;}
	// In this case there is at least two nodes
	DNode<T> *k= h->next;
	while (k != NULL){
		if (k->data >v){
			DNode<T>* pred=k->prev;
			DNode<T>* z = new DNode<T>(v,k,pred);
			pred->next=z;
			k->prev=z;
			return;
		}
		k=k->next;
	}
}

#endif