
#include "DLL.h"

template <class T>
class StackDLL
{
public:
	StackDLL();
	~StackDLL();

	void push(T& el);	// Adds an element to the stack
	T pop(void);		// Returns and Removes the last added element.
	T top(void);		// Returns the last added element.
	bool isEmpty(void);	
	void clear(void);

private:
	DLL<T> list;
};


// Constructor.
// Automatically calls the constructor of the DLList.
template <class T>
StackDLL<T>::StackDLL(void){}

// Destructor.
// Automatically calls the destructor of the DLList.
template <class T>
StackDLL<T>::~StackDLL(void){}

template <class T>
void StackDLL<T>::push(T& el)
{
	list.addLast(el);
}

template <class T>
T StackDLL<T>::pop()
{
	T el = list.getLast();
	list.delLast();
	return el;
}

template <class T>
T StackDLL<T>::top()
{
	return list.getLast();
}

template <class T>
bool StackDLL<T>::isEmpty(void)
{
	return list.isEmpty();
}

template <class T>
void StackDLL<T>::clear(void)
{
	list.clear();
}
