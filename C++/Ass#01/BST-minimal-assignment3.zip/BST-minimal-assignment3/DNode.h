#ifndef D_Header_File
#define D_Header_File

template <class T> class DLL;
/*=======================================================================*/
//								Class DNode
/*=======================================================================*/
template <class T> class DNode{
private:
	T data;
	DNode *next;
	DNode *prev;
	friend class DLL<T>;
public:
	DNode(T& data, DNode<T>* next, DNode<T>* prev);
	~DNode();
	
	T getData() ;
	DNode* getNext() ; 
	DNode* getPrev() ;
	
};

template <class T>             
DNode<T>::DNode(T& data, DNode<T>* next, DNode<T>* prev){
	this->data= data;
	this->next= next;
	this->prev= prev;
}

template <class T>             
DNode<T>::~DNode(){}

template <class T>   
T DNode<T>::getData() {return data;}

template <class T>   
DNode<T>* DNode<T>::getNext() {return next;} 

template <class T>   
DNode<T>* DNode<T>::getPrev() {return prev;}

#endif