#include "BST.h"
#include "DLL.h"
#include <iostream>
#include <math.h>
using namespace std;


int main(){

	BST<int> t1;
	t1.insert(7);
	t1.insert(6);
	t1.insert(10);
	t1.insert(4);
	t1.insert(5);
	t1.insert(9);
	
	t1.computeDepth(0);
	t1.CountDeepNodes(6);
	//t1.inOrderDFT();
	//t1.BFT();
	//std::cout<<t1.CountUnderVal(7);
	//std::cout<<t1.allNodesFull();




	return 0;
}