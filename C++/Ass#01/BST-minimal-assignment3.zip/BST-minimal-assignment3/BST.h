#include "TNode.h"
#include "QueueDLL.h"
#include "StackDLL.h"


template <class T>
class BST {
private:
	TNode<T> *root;

	void inOrderDFT(TNode<T>* c);
	void preOrderDFT(TNode<T>* c);
	void postOrderDFT(TNode<T>* c);
	void clearAll(TNode<T>* c);
	void computeNodeHeights(TNode<T>* c);
	// void computeNodeDepths(TNode<T>* n, TNode<T>* parent);
	void computeNodeDepths(TNode<T>* n, int parentDepth);
	int CountChildren(TNode<T>* node);
public:
	BST(){ root=nullptr;}
	~BST(){ clearAll();}	
	TNode<T> * getRoot() {return root;}
	bool isEmpty(void);
	bool search(T& val);
	void insert(T val); 
	void inOrderDFT(){ inOrderDFT (root);} 
	void preOrderDFT(){ preOrderDFT (root);}
	void postOrderDFT(){ postOrderDFT (root);}
	void clearAll(){clearAll(root);	root = nullptr;}
	void computeDepth(int value){computeNodeDepths(root, value);}
	void computeHeight(){computeNodeHeights(root);}
	int CountUnderVal(int val);
	void CountDeepNodes(int x);
	bool allNodesFull();
	void BFT();


};


template <class T> 
bool BST<T>::isEmpty() { 
	return root == nullptr; 
}

template <class T> 
void BST<T>:: insert(T val){
	TNode<T>* newNode = new TNode<T> (val , nullptr, nullptr);
	if (isEmpty()) {root = newNode; return;}
	TNode<T> * p = nullptr;
	TNode<T> * c = root;
	while (c!=nullptr)	{
		p = c;
		if (val> c->data) c=c->right; else c=c->left; 
	}
	if (val > p->data ) p->right = newNode; else p->left = newNode; 
}

template <class T>
void BST<T>::inOrderDFT(TNode<T>* c){
	if(c == nullptr) return;
	inOrderDFT(c->left);
	std::cout<<c->data<<", ";
	inOrderDFT(c->right);
}

template <class T>
void BST<T>::postOrderDFT(TNode<T>* c){
	if(c == nullptr) return;
	postOrderDFT(c->left);
	postOrderDFT(c->right);
	std::cout<<c->data<<", ";
}

template <class T>
void BST<T>::preOrderDFT(TNode<T>* c){
	if(c == nullptr) return;
	std::cout<<c->data<<", ";
	preOrderDFT(c->left);
	preOrderDFT(c->right);
}

template <class T>
bool BST<T>::search(T& val){
	TNode<T>* c = root;
	while(c != nullptr){
		if(val == c->data)
			return true;
		if(val <= c->data)
			c = c->left;
		else
			c = c->right;
	}
	return false;
}

template <class T>
void BST<T>::clearAll(TNode<T>* c){
	if(c == nullptr) return;
	
	clearAll(c->left);
	clearAll(c->right);	
	delete c;
}

template <class T>
void BST<T>:: computeNodeHeights(TNode<T>* c){
    if (c==nullptr)  return ;
    computeNodeHeights (c->left);
    computeNodeHeights (c->right);
    int  leftH=-1;
    if (c->left != nullptr)
          leftH= c->left->height;
    int rightH=-1;
    if (c->right !=nullptr)
          rightH= c->right->height;     
	if (leftH> rightH)
          c->height = leftH+1;
	else 
          c->height = rightH+1;
 }

// template <class T>
// void BST<T>:: computeNodeDepths(TNode<T>* n, TNode<T>* parent){
//      if (n==nullptr)   return ;
//      if (n==root)   n->depth = 0;
//      else 
//          n->depth= parent->depth+1;
//      computeNodeDepths (n->left, n);
//      computeNodeDepths (n->right, n);
// }

// Q1
template <class T>
void BST<T>:: computeNodeDepths(TNode<T>* n, int parentDepth){
     if (n==nullptr)   return ;
     if (n==root)   n->depth = 0;
     else 
         n->depth= parentDepth + 1;
     computeNodeDepths (n->left, n->depth);
     computeNodeDepths (n->right, n->depth);
}


template <class T>
void BST<T>:: BFT(){
	if (isEmpty()) return;
	QueueDLL<TNode<T>*> q;
	q.enq(root);int currentdepth=0;
	while (!q.isEmpty()){
		TNode<T>* x=q.deq();
		if (currentdepth!= x->depth){
			std::cout<<"\n"; currentdepth=x->depth;
		}
		//std::cout<<x->total_below<<",";
		std::cout<<x->data<<", ";
		if(x->left  != nullptr)q.enq(x->left);
		if(x->right != nullptr)q.enq(x->right);
	}
	//std::cout<<"\n*************************\n";
}

// Q2
template <class T>
void BST<T>:: CountDeepNodes(int val){
	
	if (isEmpty()) return;
	QueueDLL<TNode<T>*> q;
	q.enq(root);int currentdepth=0; int num = 0;
	while (!q.isEmpty()){
		TNode<T>* x=q.deq();
		if (currentdepth!= x->depth){
			std::cout<<"\n"; currentdepth=x->depth;
		}
		//std::cout<<x->total_below<<",";
		// std::cout<<x->data<<", ";
		if(x->depth > val) num+= 1;
		if(x->left  != nullptr)q.enq(x->left);
		if(x->right != nullptr)q.enq(x->right);
	}

	std::cout<<num;

}

// Q3
template<class T>
int BST<T>:: CountChildren(TNode<T>* node){
	int children_l, children_r;

	if(node == nullptr){
		return 0;
	}
	else{
		if(node->left != nullptr){
			children_l = CountChildren(node->left) + 1;
		}
		else{
			children_l = 0;
		}

		if (node->right!=nullptr){
			children_r = CountChildren(node->right) + 1;
		}
		else{
			children_r = 0;
		}
	}


	return (children_r + children_l);
}

template<class T>
int BST<T>:: CountUnderVal(int val){
	if (isEmpty()) return 0;
	QueueDLL<TNode<T>*> q;
	q.enq(root);
	int count = 0;
	bool is_present = false;
	while (!q.isEmpty()){
		TNode<T>* x=q.deq();
		if(x->data == val){
			is_present = true;
			count = CountChildren(x);
		}
		if(x->left  != nullptr)q.enq(x->left);
		if(x->right != nullptr)q.enq(x->right);
	}

	if(!is_present){
		return -1;
	}


	return count;


}

// Q4
template<class T>
bool BST<T>:: allNodesFull(){
	if (isEmpty()) return 0;
	bool is_leaf = false;
	QueueDLL<TNode<T>*> q;
	q.enq(root);
	while (!q.isEmpty()){

		TNode<T>* x=q.deq();
		if (x->left == nullptr){
			if (x->right == nullptr){
				is_leaf = true;
			}
			else{
				std::cout<< "False ";
				return false;
			}
		}
		if(x->left  != nullptr && x->right != nullptr){
			q.enq(x->left);
			q.enq(x->right);
		}

	}
	std::cout<<"True ";
	return true;


}